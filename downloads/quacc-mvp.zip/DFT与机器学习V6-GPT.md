# HANDOFF — Zn/Cu(111) DFT 项目交接（2026-10-27）

> **新会话必须先读完本文件。** 这是截至最近一次用户截图的状态，不代表计算在此后没有继续推进。用户 Windows 本机 D: 盘不可由新会话直接访问。**第一件事应读取最新 `.out`，不要根据旧截图推断当前仍处于第二轮 SCF。**

## 1. 项目目标与研究边界

研究方向：用 Quantum ESPRESSO (QE) 的 DFT 计算解释 Zn 覆层对 Cu(111) 集流体上 Na 吸附、迁移和沉积趋势的影响，为无负极钠电池提供机理支持。

计划计算链：洁净 Cu(111) 基底及参数收敛 → Zn/Cu(111) 弛豫 → 匹配洁净 Cu 参照及 Zn 体相化学势 → 覆层稳定性、功函数、差分电荷密度、PDOS → Na 吸附位点与吸附能 → CI-NEB 扩散 → 必要时覆盖度、合金化、缺陷。

**重要科学边界：** 实验背景是电化学沉积的纳米 Zn 层，尚无足以确认其原子级结构的表征。当前理想 1 ML、双面对称 Zn/Cu(111) 是**理论模型**，不能当成真实电沉积 Zn 的已证实形貌；真空 DFT 不能直接等同于电解液、SEI、电极电位下的实际循环表现。

## 2. 计算环境与文件

- Windows + PowerShell；本机 RAM 约 16 GB。
- 工作目录：`D:\QE\test\cu_bulk`
- QE 7.5 可执行文件：`D:\QE\qe-7.5-win\bin\pw.exe`
- 赝势目录：`D:\QE\pseudo`
- 赝势文件（注意 Linux 大小写敏感）：
  - `Cu_pbe_v1.2.uspp.F.UPF`
  - `zn_pbe_v1.uspp.F.UPF`
  - `na_pbe_v1.5.uspp.F.UPF`
- 原始 Zn/Cu 输入输出：
  - `cu111_6layer_zn1ml_relax.in`
  - `cu111_6layer_zn1ml_relax.out`
- **目前关键计算文件：**
  - `cu111_6layer_zn1ml_relax_k4.in`
  - `cu111_6layer_zn1ml_relax_k4.out`
  - 对应临时目录：`D:\QE\test\cu_bulk\tmp\cu111_6layer_zn1ml_relax_k4.save`（实际存在及内容须本机检查）
- 不要删除 `.save`，尤其在未确认重启需求前。

## 3. 已完成的工作（有记录支持）

### 3.1 洁净 Cu(111)

- Cu 晶格常数采用 3.63 Å。
- 2×2×6 Cu(111)，24 Cu 原子。
- 计算设置：PBE 系列赝势，`ecutwfc=55 Ry`、`ecutrho=440 Ry`、`8×8×1` k 点、Marzari–Vanderbilt (`mv`) smearing、`degauss=0.02 Ry`。
- 固定结构 SCF 的每侧真空厚度测试：

| 每侧真空厚度 (Å) | 总能量 (Ry) |
|---:|---:|
| 10 | -9690.55866475 |
| 15 | -9690.55868849 |
| 20 | -9690.55867296 |

这些仅支持固定结构条件下总能量对真空的初步不敏感；**不能称为表面能收敛、功函数收敛或全部计算参数收敛**。

### 3.2 Zn/Cu(111) 初始结构

- 2×2 Cu(111) 六层 slab，24 Cu + 上下两面各 4 Zn，共 32 原子。
- 双面对称 Zn 覆层，每侧理想 1 ML，旨在避免净偶极。
- 中间两层 Cu（8 原子）固定，其余允许弛豫。
- 初始 Zn–Cu 垂直间距约 2.20 Å。
- c 轴约 44.878907385792 Å。
- `ibrav=0`、`nat=32`、`ntyp=2`。
- x 坐标超出某个单独晶格矢量分量不一定是错误，必须按完整周期性晶格判断。

### 3.3 低内存预弛豫已实际运行

`cu111_6layer_zn1ml_relax_k4.in` 经截图检查包含：
- `calculation='relax'`、`ion_dynamics='bfgs'`
- `K_POINTS automatic` → `4 4 1 0 0 0`
- `diagonalization='cg'`
- `mixing_mode='local-TF'`
- `mixing_beta=0.20`
- `mixing_ndim=4`
- `electron_maxstep=200`
- `conv_thr=1.0d-8`
- `ecutwfc=55`、`ecutrho=440`
- `prefix='cu111_6layer_zn1ml_relax_k4'`
- `pseudo_dir='D:\QE\pseudo'`、`outdir='D:\QE\test\cu_bulk\tmp'`

**实测关键里程碑（不是预测）：**
1. 第一轮电子 SCF 共 **85 次迭代后收敛**，日志原文：`convergence has been achieved in 85 iterations`。
2. 已输出 `Forces acting on atoms`。
3. 首次受力评估 `Total force = 0.033567 Ry/au`，`Total SCF correction = 0.000943`。
4. 已出现 `BFGS Geometry Optimization`，`number of bfgs steps = 0`，以及 `ATOMIC_POSITIONS (angstrom)`。
5. 后续确实出现新的 `Self-consistent Calculation`，SCF 计数从 1 重新开始。
6. **截至最后一张截图**，第二轮 SCF 正进行至 `iteration # 3`；此前第 1、2 次迭代后 estimated SCF accuracy 分别为 `0.07102121 Ry`、`0.04822717 Ry`。还没有第二轮 SCF 收敛的证据。
7. 没有已验证的 `End of BFGS Geometry Optimization`、`JOB DONE` 或最终弛豫结构。

**特别注意：** SCF 迭代数不是 BFGS 离子优化步数；第一次 SCF 收敛和 BFGS 开始并不意味着结构优化完成。`number of bfgs steps = 0` 是当时日志记录，不要误写成已完成一个完整 BFGS 步。

## 4. 性能与是否租服务器

已记录本机 `pw.exe`：
- 进程 ID 曾为 `8960`，之后可能变化。
- 进程 Working Set 约 `2.13 GB`。
- Windows 可用 RAM 曾为 `3.96 GB`。
- 30 秒内 CPU 累计时间增长 `281.39 秒`，证明当时计算进程持续占用多核 CPU。
- 累计 CPU 时间并非墙钟时间，不能用它直接预测剩余小时数。
- Working Set 不是总峰值内存，也不能单凭它排除分页或内存带宽瓶颈。

此前曾讨论 **¥500–1000** 的第一阶段云服务器预算，并提出腾讯云 16 vCPU / 64 GB 按量测试、必要时升级 32 vCPU / 128 GB。**用户没有确认购买，不能写成已租服务器。** 历史报价仅为参考，未验证当前库存或实际成交价格。

当前策略：本机 k4 计算已跨过首轮 SCF 瓶颈，因此**先确认最新日志是否继续推进，再决定是否迁移**；若后续多个离子步极慢或发生内存/时间瓶颈，再用真实基准测试决定租用配置。不能保证云服务器一定加速收敛；它主要改善算力/内存条件。

## 5. 当前卡点与最大不确定性

**直接卡点：** 第二轮及后续离子步的 SCF 能否持续收敛，BFGS 总力是否下降，最终能否达到离子力收敛条件。最后的截图只有第二轮第 3 次电子迭代，尚无完整结构弛豫证据。

**最没有把握的事情：** 不只是“机器能不能跑”，而是**当前 4×4×1、CG 预弛豫是否能以可接受的时间获得物理上合理、数值上充分收敛的 Zn/Cu 结构**。首轮 SCF 成功不保证后续离子步成功，也不保证 Zn 1 ML 构型稳定。

**另一个必须核实的问题：** QE 结构优化中实际哪些 Cu 原子被固定、`if_pos` 标记是否正确；仅凭文字说明“中间两层固定”不能代替检查完整 `ATOMIC_POSITIONS`。

## 6. 最大遗漏：研究设计，而不只是计算速度

**最重要的缺口：匹配的洁净 Cu(111) 参照体系还未完成。**

后续比较 Zn/Cu 与 Cu 表面，至少需要匹配：晶胞横向尺寸、Cu 层数、固定层策略、真空、k 点密度、赝势、截断、smearing、能量与力收敛标准。Zn 覆层稳定性还需定义合适的 Zn 化学势（例如经验证的体相 hcp Zn 参考），双面对称模型要正确处理两个表面及相应的 Zn 数目。

**用户可能没有意识到的其他风险：**
1. 预弛豫 `4×4×1` 不是最终发表精度。结构需要在更密 k 点下复核力和总能量，必要时继续弛豫；`8×8×1` 也应验证而非视为天然充分。
2. 不能用未弛豫或不匹配的 Cu slab 与已弛豫 Zn/Cu slab 直接做吸附/覆层能比较。
3. 需要区分**几何弛豫收敛**、**SCF 收敛**、**k 点/截断收敛**和**物理模型可信性**四件事。
4. Zn 的理想满单层可能不是实际电镀的唯一形态。后续至少应考虑覆盖度或合金化/缺陷的敏感性，不能只凭一个模型解释全部实验现象。
5. Na 吸附能参考态要预先定义（孤立 Na 原子 vs Na 金属），不能把不同参考态的数值混用或直接推导钠沉积过电位。
6. 电化学过程还有电解液、SEI、电极电位与动力学；真空态 DFT 只提供受限的微观机理线索。
7. 尚未得到可用于**真实论文结果图**的 Zn/Cu 最终弛豫结构、功函数、差分电荷密度、Na 吸附能或 NEB 能垒。可以做真实初始结构图、Cu 真空测试图和已测 SCF 收敛图，但必须标明数据性质。

## 7. 绝对不要再踩的坑

1. 使用 `CELL_PARAMETERS` 却漏 `ibrav=0`：以前触发 `invalid lattice parameters (celldm or a)`，已修复。
2. 金属 slab 直接用较大的默认 `mixing_beta=0.70` 长时间盲等；此前出现 charge sloshing。当前 `local-TF`、`beta=0.20`、`cg` 已有实测改善。
3. 看到 `pw.exe` 在运行就当作计算健康；需检查日志是否推进、CPU 时间、系统内存、磁盘和是否分页。
4. 把累计 CPU 秒数误当实际经过的墙钟秒数。
5. 把 `convergence has been achieved` 误判为整个 `relax` 完成；必须检查 BFGS、力、最终坐标及结束标记。
6. 把 `number of bfgs steps = 0` 误读为已经完成一步。
7. 同时运行相同 `prefix`、`outdir` 的两个任务；不得覆盖旧结果。
8. 随意删除 `.save`、旧 `.in` 或 `.out`；先备份，确认是否要重启。
9. 在没有收敛测试时为了提速随意降低 `ecutrho`、真空或 slab 层数。
10. 将 4×4×1 预弛豫总能量作为最终发表吸附能/功函数。
11. 忘记双面对称 slab 两个表面，在表面能/覆盖能定义中漏掉对应计数因子。
12. 把固定结构真空 SCF 测试说成“表面能已收敛”。
13. 把理想 1 ML Zn 模型当作实验电沉积的已验证真实结构。
14. **不要用日志里新出现的 `ATOMIC_POSITIONS` 就断言结构最终收敛**。
15. PowerShell 当前目录必须是 `D:\QE\test\cu_bulk`；`.out` 文件名为 `..._k4.out`，此前因文件尚未生成发生过 `PathNotFound`。
16. 用户希望**一次解决一个问题**：先判断，再给一条可执行的 PowerShell 检查命令，不要一次布置十项操作。

## 8. 新会话的第一步（唯一优先动作）

请让用户在 Windows PowerShell 执行**只读**命令：

```powershell
cd D:\QE\test\cu_bulk
Select-String .\cu111_6layer_zn1ml_relax_k4.out -Pattern "convergence has been achieved|convergence NOT achieved|iteration #|estimated scf accuracy|Total force|number of bfgs steps|End of BFGS|JOB DONE|Error in routine" | Select-Object -Last 30
```

请用户粘贴输出或截图。根据结果判断：
- 第二轮 SCF 是否收敛；
- 是否出现新的 `Total force`、是否比首次的 `0.033567 Ry/au` 下降；
- BFGS 是否有进一步的优化步；
- 是否有 `JOB DONE` 或异常终止；
- 若输出已完成，再检查最后坐标、力收敛和文件完整性。

**不要在没有新日志时让用户停止、重启或租服务器。**

## 9. 导师汇报与论文图需求

用户需要向导师直观汇报研究进度，并制作论文级图片。当前可严谨汇报：
- 已完成洁净 Cu(111) 基础模型与固定结构真空测试；
- 已建立 32 原子双面对称 Zn/Cu(111) 理想覆层模型；
- 低内存预弛豫首轮 SCF 已在 85 次迭代后收敛；
- 已获得初始受力 `0.033567 Ry/au`，BFGS 已启动；
- 最新已知进入第二轮 SCF，**尚未获得最终弛豫结构**。

当前可以制作：洁净 Cu(111) 真空测试图、已测 SCF 收敛图、**根据真实输入坐标**的弛豫前结构图。制作原子结构图必须从用户真实 `.in`/`.out` 提取完整坐标；不能凭示意图虚构。

等待数据后制作：优化前后 Zn–Cu 层间距、BFGS 总力变化、功函数、差分电荷密度、Na 位点吸附能、NEB 能垒。

## 10. 协作原则

- 中文、准确、简洁、循序渐进。
- 关键结论尽可能两种独立证据交叉核对；数值用 Python 计算并反算。
- 涉及可能变化的 QE 技术细节查官方资料。
- 不把未经收敛验证的结果当可靠科学结论。
- 新会话**优先读取本文件、核对最新日志**，避免重走已解决的首轮 SCF 排查流程。

---
**一句话接力：** Zn/Cu(111) 低内存预弛豫已在首轮 SCF 85 次迭代后收敛并进入 BFGS，最后记录停在第二轮 SCF 第 3 次迭代；下一步不是重建模型或立即租服务器，而是读取最新 `..._k4.out`，确认后续电子与离子收敛进展。
