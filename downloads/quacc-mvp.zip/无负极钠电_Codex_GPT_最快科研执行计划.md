# 无负极钠电 + 机器学习：最快拿到结果的执行计划

> 目标：基于老师提出的“单原子集流体 + 机器学习筛选 + 死钠复活”思路，结合截至 2026 年 9 月的研究进展，尽快形成可靠计算结果、可验证实验候选和论文级故事线。  
> 原则：先拿可靠数据，再上机器学习；先建立最小闭环，再扩大体系；并行推进“快线”和“高创新线”。

## 一、先确定最终研究路线

不要把全部工作揉成一个大课题同时启动。拆成两条并行线：

### A 线：快速产出线——单原子修饰集流体的 DFT + ML 筛选

目标：

> 从一批候选金属中筛出能够稳定锚定于 Cu 基底、调控 Na 成核/迁移，并有希望降低死钠生成的单原子位点。

这条线适合快速建立：

- DFT 数据库
- ML 模型
- SHAP/描述符分析
- 候选材料排序
- 第一批论文图
- 实验 Top 3–5 候选

但必须注意：

**“亲钠金属修饰集流体”本身已经不是新概念。**

因此 A 线不能停留在：

> Au 比 Cu 好、Sn 比 Cu 好、Na 吸附能更负。

必须做到：

> 稳定锚定 + 适中 Na 吸附 + 快速表面迁移 + 可解释电子结构 + ML 提取设计规律。

### B 线：高创新主线——化学介体实现 dead Na 再活化

目标：

> 筛选能够与失活 Na 发生可逆电子/化学反应的 redox mediator，使 dead Na 重新转化为可利用的 Na 物种，并在电池中循环再生。

这是目前更值得抢的方向。

截至 2026 年已经出现：

- 反向脉冲充电实现 dead Na 再活化；
- 过放电界面重构实现 dead Na 再活化；
- 数据驱动无负极 Na 电解液设计。

因此不能再把创新点写成：

> “首次提出死钠复活。”

应该改成：

> “化学/氧化还原介体驱动的 dead Na 主动回收机制”

如果能够与单原子集流体结合，可以进一步形成：

> 前端减少 dead Na 形成 + 后端回收已经形成的 dead Na。

---

## 二、第一件事：确认老师录音中的 “Nafion” 到底是什么

这是当前优先级最高的事情之一。

录音识别出的“Nafion”很可能存在语音识别错误。

必须确认老师真正指的是：

- Nafion？
- 某种有机氧化还原分子？
- 某种自由基介体？
- 某种离子液体？
- 某个具体缩写？

### 为什么必须先确认

如果它是一个可逆氧化还原介体，那么整个 B 线的核心反应可能是：

```text
Mediator + e− ⇌ Mediator−
```

随后：

```text
Mediator / Mediator− + dead Na
→ 可迁移 Na+ + 再生的 Mediator
```

那么研究重点就不是 Nafion 膜，而是：

- 氧化还原电位
- 与 Na 的反应自由能
- 电子转移
- 电化学稳定窗口
- 正极兼容性
- SEI 兼容性

**在分子身份没有确认以前，不要投入大量计算。**

---

## 三、最快的总体时间表

以下时间以“有正常计算资源”为前提；真正耗时取决于服务器排队、DFT 收敛和实验条件。

### 0–48 小时：完成课题定义，不做大规模计算

你需要完成：

1. 确认老师所说的具体分子/添加剂名称。
2. 确认实验室现有条件：
   - Cu 箔还是 Al 箔？
   - 是否能做单原子负载？
   - 是否有 XPS / SEM / TEM / ICP？
   - 是否能够组装 Na||Cu 半电池？
   - 是否能够做无负极全电池？
   - 是否能做脉冲/过放电等电化学程序？
3. 确认可用计算资源：
   - VASP / Quantum ESPRESSO
   - ORCA
   - HPC 队列
   - CPU/GPU 数量

GPT 做：

建立一张“前人工作冲突矩阵”：

| 方向 | 前人是否做过 | 已做到什么程度 | 还能做什么 |
|---|---|---|---|
| Au/Cu 亲钠集流体 | 是 | 已有大量工作 | 不能单独作为创新 |
| Sn/Cu 修饰 | 是/高度接近 | 已有亲钠层/合金思路 | 需要原子级机制 |
| ML 优化成核层 | 是 | Bayesian optimization 已出现 | 需要新变量/新机制 |
| ML 电解液设计 | 是 | 2026 JACS 已出现 | 不宜简单重复 |
| dead Na 再活化 | 是 | 脉冲与过放电路线已出现 | 化学介体仍值得深挖 |
| 单原子 + dead Na 抑制/复活 | 尚需重点核查 | 可能存在窗口 | 高优先级 |
| redox mediator + dead Na | 尚需重点核查 | Li 中已有类似思想 | Na 体系可能是核心窗口 |

Codex 做：

建立项目仓库：

```text
anode_free_na/
├── README.md
├── literature/
├── structures/
│   ├── pristine/
│   ├── single_atom/
│   └── na_adsorption/
├── dft/
│   ├── inputs/
│   ├── jobs/
│   ├── outputs/
│   └── parsers/
├── database/
│   └── dataset.csv
├── ml/
│   ├── notebooks/
│   ├── src/
│   └── models/
├── mediator/
│   ├── molecules/
│   ├── xtb/
│   ├── dft/
│   └── database/
├── figures/
└── reports/
```

---

## 四、第 1–3 天：先复现，不要创新

第一目标不是“发现新材料”。

第一目标是：

> 证明你的计算流水线是对的。

### A 线基准体系

建议先做：

```text
Na on Cu(111)
Na on pristine Cu
Na on Au-modified Cu
Na on Sn-modified Cu
```

如果老师后续坚持某种特定 Cu 晶面，则换成对应晶面。

同时建议保留一个 Al 基准，因为无负极 Na 领域近年 Al 集流体非常活跃。

### 必须复现的指标

至少包括：

```text
E_ads(Na)
E_anchor(M)
work function
optimized geometry
```

如果文献中有数据，再比较：

```text
Na diffusion barrier
```

### Go / No-Go 标准

只有当：

```text
你的计算趋势 ≈ 已发表趋势
```

并且数值差异能够通过：

```text
泛函
赝势
超胞
覆盖度
k 点
吸附位点
```

解释以后，才能开始批量计算。

---

## 五、第 1 周：建立第一批真正的数据

不要一上来计算几百个体系。

第一批目标：

**20–40 个可靠样本。**

### 候选金属池

第一版可以从这些元素开始：

```text
Mg Al Ti V Cr Mn Fe Co Ni
Zn Ga Ge Ag In Sn Sb
Pd Pt Au Bi
```

不用一次全部做完。

优先保证：

- 元素性质差异足够大；
- 有贵金属；
- 有后过渡金属；
- 有 p 区金属；
- 有低成本候选。

### 第一阶段每个体系只算三个东西

#### 1. 单原子锚定稳定性

```text
E_anchor
```

回答：

> 这个单原子能否在 Cu 上稳定存在？

#### 2. Na 吸附能

```text
E_ads(Na)
```

回答：

> Na 是否愿意在这个位点成核？

#### 3. 功函数

```text
Work Function
```

回答：

> 单原子是否改变了表面电子转移性质？

### 暂时不要批量做

以下项目计算较贵：

```text
NEB
AIMD
大规模 Bader
大量 DOS
大尺寸 Na cluster
```

先筛掉 70%–80% 的差候选。

---

## 六、Codex 在第 1 周真正应该帮你做什么

### 任务 1：自动生成结构

让 Codex 写：

```text
build_surfaces.py
place_single_atom.py
place_na.py
```

功能：

- 读取 Cu bulk；
- 自动建立指定晶面 slab；
- 建立不同 adsorption site；
- 建立 substitution/vacancy 模型；
- 放置 M 单原子；
- 放置 Na；
- 自动避免明显原子重叠；
- 输出 POSCAR/CIF。

### 任务 2：自动生成 DFT 输入文件

写：

```text
generate_vasp_inputs.py
```

或 Quantum ESPRESSO 对应脚本。

必须支持：

```text
relax
static
DOS
NEB
```

不同任务使用不同模板。

### 任务 3：自动检查计算状态

写：

```text
check_jobs.py
```

自动识别：

```text
完成
未收敛
电子步失败
离子步未结束
结构异常
文件缺失
```

不要每天人工打开几十个 OUTCAR。

### 任务 4：自动提取数据库

写：

```text
parse_results.py
```

输出：

```text
dataset.csv
```

至少包含：

```text
dopant
facet
site
E_total
E_anchor
E_ads_Na
work_function
converged
calculation_date
```

---

## 七、可直接交给 Codex 的第一条任务

```text
你是这个项目的科研计算工程助手。

项目目标：
建立“单原子修饰 Cu 集流体用于无负极钠金属电池”的自动化 DFT 数据生成流水线。

请先不要修改任何物理定义。第一步完成以下任务：

1. 创建规范项目目录。
2. 使用 ASE/pymatgen 建立 Cu(111) slab。
3. 自动生成 pristine Cu、M@Cu、Na@M-Cu 三类结构。
4. M 首先测试 Au、Sn、Zn、Ag、Bi。
5. 所有结构和元数据必须有唯一 ID。
6. 生成 VASP 输入，但 INCAR 参数单独写成配置文件，不要硬编码。
7. 写结果解析器，读取能量、收敛状态和结构。
8. 建立 dataset.csv。
9. 给所有脚本写单元测试。
10. 不允许静默忽略失败计算。
11. 任何吸附能/锚定能公式必须写在 README 中，由我确认以后才能批量执行。

完成后给出目录结构、运行命令、测试结果和仍需我决定的物理参数。
```

---

## 八、GPT 在第 1 周真正应该做什么

GPT 不负责替你“算出结果”。

GPT 主要承担四个角色：

### 角色 1：文献审稿人

每做一个体系，都问：

> 这个结果是否已经有人做过？

### 角色 2：物理定义审查

把下面这些公式交给 GPT 检查：

```text
E_anchor
E_ads
E_cohesive comparison
diffusion barrier
formation energy
```

确认参考态是否合理。

### 角色 3：结果异常诊断

例如：

```text
为什么 Au@Cu 的吸附能异常？
为什么 Sn 原子跑进表面？
为什么某个体系磁矩异常？
为什么不同超胞结果变化巨大？
```

让 GPT 帮你提出检查顺序。

### 角色 4：论文故事线维护

每周把当前结果给 GPT，让它回答：

```text
1. 现在最强的结论是什么？
2. 哪个结论证据不足？
3. 下一项计算对论文价值最大？
4. 哪项计算可以删掉？
5. 当前结果与 2026 最新工作相比还有没有新意？
```

---

## 九、第 2 周：开始机器学习

**机器学习不是第一周开始。**

至少得到约 30–50 个可信数据后再开始。

### 第一版 ML 标签

只预测：

```text
E_anchor
E_ads_Na
```

### 特征

元素本征属性：

```text
atomic number
atomic radius
covalent radius
electronegativity
electron affinity
ionization energy
group
period
valence electrons
d-electron count
melting point
```

结构属性：

```text
M-Cu distance
coordination number
site type
surface facet
height above surface
```

后期加入：

```text
work function
Bader charge
d-band center
```

### 第一批模型

不要神经网络。

训练：

```text
Linear Regression
Random Forest
XGBoost
Gaussian Process Regression
```

### 评估指标

```text
MAE
RMSE
R²
```

但要特别注意：

如果同一个元素的多个结构同时进入 train 和 test，容易发生数据泄漏。

至少增加：

```text
GroupKFold by dopant
Leave-One-Element-Out
```

这样才能证明模型真的能预测“没见过的新元素”。

---

## 十、Codex 的第二阶段任务：ML 自动化

```text
基于 database/dataset.csv 建立可重复的机器学习流水线。

要求：

1. 自动完成缺失值检查。
2. 自动生成元素描述符。
3. 特征与标签严格分离。
4. 实现 Linear Regression、Random Forest、XGBoost、Gaussian Process。
5. 同时实现随机交叉验证和 GroupKFold(dopant)。
6. 输出 MAE、RMSE、R²。
7. 输出 parity plot。
8. 输出 feature importance。
9. 对树模型加入 SHAP。
10. 保存模型、配置文件和随机种子。
11. 自动生成 model_report.md。
12. 如果样本量不足，必须明确警告，不允许为了得到高 R² 进行数据泄漏。
```

---

## 十一、第 2–3 周：主动学习，不要暴力算

训练第一版 GPR 后：

```text
已计算 40 个
     ↓
预测未计算候选
     ↓
同时查看：
prediction
uncertainty
     ↓
挑选 10–15 个最有信息量的候选
     ↓
继续 DFT
     ↓
重新训练
```

候选选择不要只选“预测最好”。

应该组合：

```text
高性能候选
+
高不确定度候选
```

这样最快提高模型有效性。

---

## 十二、第 3 周：只对 Top 候选做高成本计算

如果已经筛出：

```text
Top 5–8
```

再计算：

### Na 扩散

```text
CI-NEB
E_diff
```

### 电荷分析

```text
Bader charge
charge density difference
```

### 电子结构

```text
DOS
PDOS
d-band center
```

### 必要时

```text
多个 Na 原子
Na cluster
更高覆盖度
```

---

## 十三、第 3–4 周：形成第一批论文级图

### Figure 1

```text
研究框架
候选元素空间
DFT → ML → Active Learning → Experiment
```

### Figure 2

```text
E_anchor
vs
E_ads(Na)
```

二维筛选地图。

### Figure 3

```text
DFT vs ML
parity plot
```

### Figure 4

```text
SHAP
```

回答：

> 哪些元素性质控制 Na 吸附？

### Figure 5

Top 候选：

```text
diffusion barrier
charge transfer
DOS
```

---

## 十四、实验不要等 ML 全部做完再开始

当出现第一批明显候选：

```text
Top 3
+
1 个 pristine Cu control
+
1 个已知有效材料 control
```

立即交实验。

不要等你把 20 种元素全部算完。

---

## 十五、实验最小验证集

### 1. 单原子是否存在

优先：

```text
HAADF-STEM
XPS
ICP
```

根据实验条件选择。

### 2. Na 成核是否改善

```text
Na||Cu
nucleation overpotential
```

### 3. CE 是否提升

```text
Na plating/stripping CE
```

### 4. Na 形貌

```text
SEM
```

先做到这四个。

这已经足够决定候选是否值得继续。

---

## 十六、B 线必须从第 1 周并行开始

不要等 A 线做完。

因为真正有可能形成高创新文章的是：

> dead Na chemical reactivation

---

## 十七、B 线第一步：不是机器学习，而是分子候选库

先从以下来源建立候选：

```text
dead Li reactivation literature
redox mediator literature
redox shuttle literature
Na battery additives
organic radical molecules
quinone-type redox systems
```

先收集：

**50–200 个分子。**

每个分子保存：

```text
SMILES
molecular weight
known redox potential
solubility
electrolyte compatibility
reported battery system
reference
```

---

## 十八、B 线最快的计算策略

不要直接对 200 个分子跑昂贵 DFT。

使用三级筛选：

### Level 1：RDKit / xTB

快速计算：

```text
molecular descriptors
HOMO/LUMO trend
geometry
dipole
basic electronic descriptors
```

快速删掉明显不合适分子。

### Level 2：量子化学 DFT

对约：

```text
20–40 个
```

候选进一步算：

```text
oxidation/reduction free energy
redox potential
Na binding
solvation energy
frontier orbitals
reaction thermodynamics
```

建议分子计算优先考虑：

```text
ORCA
```

或实验室已有量化软件。

### Level 3：反应机理

只对：

```text
Top 3–5
```

研究：

```text
Mediator + dead Na
```

相关电子转移/反应路径。

---

## 十九、B 线最重要的筛选条件

一个好的 mediator 至少同时满足：

```text
能与 dead Na 发生有利反应
+
本身能够再生
+
电位位于合理窗口
+
不持续攻击新鲜 Na
+
不严重攻击正极
+
不显著分解电解液
+
有足够溶解度
+
反应动力学足够快
```

所以不能只比较：

```text
HOMO/LUMO
```

也不能只比较：

```text
Na binding energy
```

---

## 二十、B 线什么时候需要机器学习

如果最终只有：

```text
20 个分子
```

不要为了“用了 ML”硬训练模型。

直接：

```text
xTB + DFT + 实验
```

可能更快。

当候选库达到：

```text
100–500+
```

再训练：

```text
RF
XGBoost
GPR
```

预测：

```text
redox potential
reaction free energy
solvation property
```

---

## 二十一、可以交给 Codex 的 B 线任务

```text
建立一个 redox-mediator 高通量筛选流水线。

输入：
candidate_mediators.csv，其中包含 name 和 SMILES。

要求：

1. 使用 RDKit 生成分子结构与基础描述符。
2. 生成多个构象。
3. 建立 xTB 预筛脚本。
4. 自动解析 xTB 结果。
5. 按统一字段写入 mediator_dataset.csv。
6. 对筛选后候选自动生成 ORCA 输入文件。
7. 支持 neutral / oxidized / reduced 三种电荷态。
8. 自动提取总能、自由能、轨道信息。
9. 所有单位必须统一。
10. 所有失败任务必须记录原因。
11. 不允许凭空填充未完成计算的数据。
12. 输出一个候选排序报告，但不要擅自定义最终评分函数，评分权重由我确认。
```

---

## 二十二、GPT 在 B 线要做的工作

让 GPT 逐篇阅读关键论文，然后输出统一格式：

```text
分子
氧化还原反应
电位
作用对象
是否真正回收 dead metal
副反应
循环方式
电解液
正极
实验验证
局限
可否迁移到 Na
```

最终形成：

```text
literature/redox_mediator_matrix.csv
```

---

## 二十三、不要让 GPT/Codex 做的事情

### 不能让 GPT 决定

```text
某材料一定最优
某机制一定成立
某 DFT 数值一定正确
某峰一定属于某化学键
```

必须有计算/实验支持。

### 不能让 Codex 自己决定

```text
DFT 参考态
吸附能定义
赝势
U 值
磁性
表面覆盖度
最终候选评分权重
```

这些属于科研判断。

---

## 二十四、每天的工作方式

不要按传统方式：

```text
今天看论文
明天写脚本
后天检查计算
```

应该三线并行：

### 你

```text
物理问题
计算检查
关键结果判断
实验沟通
```

### GPT

```text
文献
假设
异常分析
结果解释
论文逻辑
```

### Codex

```text
代码
批处理
自动化
数据解析
ML
绘图
测试
```

---

## 二十五、每天固定让 GPT 做一次“科研审计”

```text
这是我今天新增的全部结果。

请你不要帮我包装结果，而是作为严格审稿人完成：

1. 哪些结果可靠？
2. 哪些结果可能是计算假象？
3. 哪些结论证据不足？
4. 与最新文献相比是否仍有创新？
5. 明天最应该做哪 3 项计算/实验？
6. 哪些任务可以直接取消？
7. 如果目标是最快形成一篇高水平论文，当前瓶颈是什么？
```

---

## 二十六、每周固定让 Codex 做一次项目审计

```text
审计整个项目仓库：

1. 找出失败或未收敛计算。
2. 检查数据库是否存在重复结构。
3. 检查单位是否一致。
4. 检查公式是否被不同脚本实现成不同版本。
5. 检查 ML 是否有数据泄漏。
6. 检查随机种子和配置文件是否保存。
7. 检查图片是否能从原始数据一键重现。
8. 输出 audit_report.md。
9. 不修改原始数据。
```

---

## 二十七、你的 7 天目标

7 天后至少应该拥有：

```text
✓ 完整项目仓库
✓ 文献冲突矩阵
✓ 1 个已复现的基准体系
✓ 5–10 个单原子测试体系
✓ 自动生成结构脚本
✓ 自动提交/检查计算脚本
✓ 自动数据解析脚本
✓ dataset.csv v0.1
✓ dead Na mediator 候选表 v0.1
```

如果 7 天后还主要停留在：

```text
看论文
学机器学习课程
讨论概念
```

说明节奏太慢。

---

## 二十八、你的 14 天目标

14 天后争取：

```text
✓ 30–50 个可靠 DFT 数据
✓ 第一版 E_anchor / E_ads 数据地图
✓ 第一版 ML baseline
✓ RF/XGBoost/GPR 比较
✓ 第一版 SHAP
✓ Top 候选
✓ mediator 候选缩小到 20–40 个
✓ 一批 mediator xTB / DFT 初筛数据
```

此时应该能够向老师汇报：

> 我们不是“计划做机器学习”，而是已经有一套数据驱动筛选结果。

---

## 二十九、你的 30 天目标

30 天后理想状态：

```text
A 线：
✓ 50–100 个高质量结构数据
✓ Active Learning 至少 1 轮
✓ Top 5 候选
✓ Top 候选 NEB
✓ Bader / DOS / charge density
✓ 第一批实验反馈

B 线：
✓ mediator database
✓ 20–40 个量化结果
✓ Top 3–5 分子
✓ 初步 reaction thermodynamics
✓ 至少 1–2 个分子进入实验验证
```

---

## 三十、30 天后做第一次真正的 Go / No-Go

### A 线继续的条件

满足至少两个：

```text
出现明显优于已知 Au/Sn/Bi 等基准的候选
发现稳定且可解释的结构—性能规律
ML 能够发现人工难以直接看出的 descriptor
实验趋势支持计算
```

否则：

> A 线降级为辅助机制工作。

### B 线继续的条件

满足至少一个：

```text
存在 thermodynamically favorable 的 dead Na 反应候选
介体具有合理 redox window
初步实验显示 lost capacity 可被恢复
存在明确可逆循环机制
```

如果出现其中任意一项：

> B 线立即升为主线。

---

## 三十一、最推荐的论文故事

最终不要写成：

```text
机器学习筛选了材料
→ 找到 X
→ X 循环很好
```

更强的故事是：

```text
无负极 Na 的核心问题
        ↓
Active Na Loss
        ↓
两个控制节点
┌────────────────────┐
│                    │
↓                    ↓
dead Na formation    dead Na already formed
│                    │
↓                    ↓
single-atom host     redox mediator
│                    │
↓                    ↓
suppress loss        recover loss
└────────┬───────────┘
         ↓
closed-loop Na inventory management
         ↓
long-life anode-free Na battery
```

机器学习的作用是：

```text
accelerate discovery
+
extract design rules
```

而不是论文卖点本身。

---

## 三十二、真正值得追求的创新表达

如果最终数据支持，可以把课题升级为：

> **Data-driven closed-loop active-sodium inventory management for anode-free sodium batteries**

中文：

> **数据驱动的无负极钠电池活性钠库存闭环调控**

核心两部分：

```text
Prevent dead Na
+
Reactivate dead Na
```

这比：

> “机器学习筛选单原子”

明显更完整。

---

## 三十三、你现在今天就应该做的事情

按优先级：

### P0

```text
确认老师口中的“Nafion”真实名称。
```

### P1

```text
让 GPT 建最新文献冲突矩阵。
```

### P2

```text
让 Codex 建项目仓库和 Cu slab 自动生成程序。
```

### P3

```text
复现 1 个 published baseline。
```

### P4

```text
只计算 Au / Sn / Zn / Ag / Bi 五个测试元素。
```

### P5

```text
同时让 GPT 建 dead-Li / dead-Na redox mediator 候选表。
```

### P6

```text
让 Codex 建 mediator RDKit+xTB 预筛流水线。
```

做完以上七步以后，再决定是否扩展到 20+ 元素。

---

## 三十四、资源优先级

如果计算资源有限：

```text
优先级 1：结构优化 + E_anchor + E_ads
优先级 2：mediator 快速量化筛选
优先级 3：Top candidate NEB
优先级 4：Bader / DOS
优先级 5：AIMD
```

不要一开始做 AIMD。

---

## 三十五、最容易浪费时间的 8 件事

不要：

1. 系统学几个月机器学习再开始；
2. 一开始做深度学习；
3. 一开始批量 NEB；
4. 同时研究 Cu、Al、Ni、Ti 多种基底；
5. 同时研究液态和固态电解质；
6. 为了 ML 人为制造很多高度相似数据；
7. 等所有计算完成再联系实验；
8. 在没有确认“Nafion”真实名称以前大规模计算。

---

## 三十六、截至 2026 年 9 月必须正面对比的工作

### Dead Na reactivation

**Wang et al., Nature Communications, 2026**  
*Reactivating dead sodium for durable and high-rate anode-free sodium batteries*  
DOI: `10.1038/s41467-026-72848-0`

核心：

```text
reverse-pulse-interspersed charging
+
dielectrophoresis
+
dead Na reactivation
```

你的工作必须解释：

> 为什么 chemical mediator 与它不同？

### Dead Na interface reconstruction

**Wang et al., Advanced Materials, 2026**  
*Interface Reconstruction Reviving Dead Na Enables 3,800-Cycle Ah-Level Anode-Free Sodium Batteries*  
DOI: `10.1002/adma.74820`

核心：

```text
tailored overdischarge
+
SEI dissolution/reconstruction
+
dead Na revival
```

你的工作必须解释：

> 为什么 mediator 不是另一种“过放电”？

### ML electrolyte design

**Su et al., JACS, 2026**  
*Data-Driven Knowledge Discovery Reveals Quantitative Electrolyte Design Rules for Anode-Free Sodium Metal Batteries*  
DOI: `10.1021/jacs.6c05130`

核心：

```text
interpretable ML
+
electrolyte descriptors
+
CE design rule
```

所以你的 ML 必须避免变成：

> 又一个“电解液 ML 预测 CE”。

### Active Na loss framework

**Qiu et al., Energy & Environmental Science, 2026**  
*Active sodium loss in practical anode-free sodium batteries: mechanisms, challenges, and strategies*  
DOI: `10.1039/D6EE00760K`

建议把这篇作为整个项目的问题定义框架：

```text
active Na inventory
```

而不是简单的：

```text
dendrite suppression
```

---

## 三十七、一句话最终路线

```text
今天：
确认分子 + 建仓库 + 复现基准

第 1 周：
拿到第一批 DFT + mediator database

第 2 周：
30–50 个 DFT + 第一版 ML + mediator 快筛

第 3 周：
Active Learning + Top candidate NEB + mediator DFT

第 4 周：
Top candidate 实验 + dead Na chemical reactivation 初步实验

之后：
把“抑制 dead Na 生成”和“回收 dead Na”合并为
active Na inventory closed-loop management
```

---

## 三十八、如何判断你是否真的在“利用 AI 加速科研”

正确状态应该是：

```text
人工提出科学问题
↓
GPT 快速读文献、审查假设
↓
Codex 自动执行重复计算工作
↓
DFT / 实验产生真实数据
↓
ML 从真实数据中提取规律
↓
GPT 帮助寻找漏洞和下一步
↓
Codex 执行下一轮
↓
人工做最终科学判断
```

而不是：

```text
问 GPT 哪个材料最好
↓
直接相信答案
```

---

## 最终优先级

```text
P0  确认 mediator 真名
P1  做 novelty map
P2  复现计算基准
P3  自动化 DFT
P4  20–40 个真实数据
P5  ML baseline
P6  主动学习
P7  Top 候选高精度计算
P8  立即实验验证
P9  dead Na mediator 机制
P10 双路线合并
```

**最快拿到高价值结果的方法不是“让 AI 替你做科研”，而是让 GPT 消灭检索、阅读和逻辑整理的时间，让 Codex 消灭建模、批处理、解析、训练和绘图中的重复劳动，把你自己的时间集中到“哪些数据可信、哪个实验最关键、哪个机制值得继续”这三件事上。**
