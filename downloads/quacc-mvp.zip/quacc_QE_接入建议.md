# quacc 承接 Zn/Cu(111) 后续 QE 计算的建议

核查日期：2026-10-27。核查源码固定在 quacc commit `c37a7d7694004422268c9efc8eb89b388192439f`；这不是已经安装或验证过的本机环境。

## 结论

可以使用 quacc 作为后续 QE 计算的组织层。推荐直接调用其公开 API，补少量项目配置和数据质量检查，不 fork/修改 quacc 源码，也不开发另一套通用工作流平台。

它负责调用 QE、组织目录与文件、连接任务和汇总结果，不替代 QE，不保证电子/离子收敛，不定义本课题的物理参考态，不会仅因使用 quacc 而使同一计算更快。

当前 Windows 上运行中的 pw.exe/BFGS 继续按原任务处理。本轮不停止、不接管、不重启，不向其 prefix/outdir 或 .save 写文件。

## 已核实的功能与边界

| 本课题步骤 | quacc 已有功能 | 仍需本项目负责 |
|---|---|---|
| 固定结构 SCF、参数复核 | espresso.core.static_job | 确定并记录匹配协议、可接受的误差与比较对象 |
| Cu、Zn/Cu、Na吸附结构弛豫 | espresso.core.relax_job | 结构与位点生成、固定原子、覆盖度、磁态、阈值；slab 通常保持晶胞，不盲目使用 vc-relax |
| 几何优化的另一种实现 | espresso.core.ase_relax_job | 这是 ASE 外部优化，不等同于 QE 原生 BFGS；当前路线优先原生 relax_job |
| DOS/PDOS | espresso.dos 中的 dos/projwfc jobs 与 flows | SCF/NSCF 网格、空带、展宽和后处理文件一致性 |
| 电荷密度、静电势后处理 | espresso.core.post_processing_job 可调用 pp.x | 功函数的真空参考与平面平均；差分电荷的同晶胞、同网格及参考体系；不能把“输出文件生成”当物理验证 |
| Zn 覆层能、Na 吸附能 | 可组织相关参考作业并读取能量 | 匹配 Cu/金属参考、正确原子计数、参考态、双面与归一化公式必须单独定义并批准 |
| CI-NEB | 配置中可映射 neb.x，但所查版本的 espresso recipes 目录没有独立 neb 模块 | 后续核查 ASE/通用 runner 或自定义薄封装，并验证初末态、插值、约束、images 与势垒收敛；现在不能承诺开箱即用的 QE CI-NEB |

## 与当前设置的关键差异

所查版本的金属默认值包含 cold smearing、degauss=0.01 Ry、mixing_beta=0.35，默认 preset 为 `sssp_1.3.0_pbe_efficiency`。现有摘要报告不同的赝势文件，洁净 Cu 使用 mv/degauss=0.02 Ry，Zn/Cu k4 使用 mixing_beta=0.20、CG、mixing_ndim=4。

这些差异不能悄悄带入新任务。cold 与 mv 的命名在 QE 中有关联，但数值展宽和其他输入仍必须逐项核对；不能仅比较几个可见参数就认定协议相同。切换赝势还会使绝对总能比较失去直接意义。

接入时以真实输入为准，明确禁用不适用的默认 preset 或完整覆盖它，显式映射：

- Cu/Zn/Na 赝势文件、路径、文件头来源与 SHA-256。
- 55/440 Ry 截断、k 点及偏移、smearing/degauss。
- diagonalization、mixing_mode/beta/ndim、electron_maxstep 与 conv_thr。
- relax/BFGS、etot_conv_thr/forc_conv_thr、固定原子的实际约束。
- 晶胞、坐标、原子顺序和 nat/ntyp；生成的 QE 输入中逐项复核，而非只检查 Python 对象。
- 新任务的独立结果、scratch 和临时目录，不复用正在运行的旧 outdir。

## 平台选择

quacc 官方安装文档对 Windows 推荐 WSL。源码也允许配置可执行文件名与目录，但尚未测试用户的 Windows QE 7.5 pw.exe 与 quacc 的完整兼容性，因此不声称只填一个路径即可工作。

建议：当前原生 Windows 任务先保留；后续统一环境优先考虑 Linux/WSL。WSL 下应使用已验证的 Linux QE 程序与相应并行配置，不能默认原来的 Windows pw.exe 与 Linux MPI 可互换。

若使用 WSL，需要先规划发行版存储、环境、缓存、临时目录和结果路径，满足用户 D:\Codex 的要求。默认安装可能写入 C:；本轮不进行安装或授权任何 C: 写入。云端文档继续位于获准的 /workspace/Codex。

CPU/MPI/线程数需依据实际 QE 构建与内存测试决定。quacc 可以设置并行命令，但不能保证多核越多越快，也不自动解决 charge sloshing。

## 最小接入与验收顺序

1. **真实输入审查**：取得现用 `cu111_6layer_zn1ml_relax_k4.in`，先完成输入—配置逐项映射，不改动旧作业。
2. **输入等价性检查**：在独立目录检查新输入的几何、约束、赝势与计算参数。quacc 的 `test_run=True` 会调用 QE 并利用 EXIT 文件提前退出，不应宣传为完全不执行程序的纯 dry-run。
3. **一个同协议静态 SCF 对照**：选定同一真实结构，比较直接 QE 与 quacc 调用 QE 的输入、能量、力和正常结束状态。先约定数值容差；不同几何或不同参考能不能用于这个对照。
4. **单条后续工作流**：验证通过后，先做匹配洁净 Cu 参照或一个已批准的新静态任务，再逐步接入 Zn/Na 参考、吸附与后处理。是否需要重新弛豫由数值验证决定，不自动重算全部旧结果。
5. **数据库衔接**：保留原始 QE 文件与协议、结构、来源和任务状态；只有验收通过的结果才进入物理比较。现有 sources/observations/definitions 继续作为质量审查入口。

初期本地串行运行任务即可；quacc 的 workflow engine 可为 None，不必先搭建集群、数据库或长期守护服务。

## 不把文件复用误认为任意重启

quacc 的 prev_outdir/copy_files 可复用前序文件，但不自动保证从任意旧 BFGS 中无损接管。源码会管理 QE 的输出路径；prev_outdir 还可能直接使用并解压既有目录。因此现有 .save 应保留且不可让新任务直接指向它。

最稳妥的边界是：旧任务完成并验收后，以最终几何开始独立的新任务。若确需沿用电荷密度或波函数，必须先复制保护旧文件，再核对 QE 版本/构建、晶胞、k 点、赝势、并行兼容与 restart 设置；本轮没有验证跨 Windows/Linux 的 .save 可移植性。

## 一手源码

- [安装说明：Windows 推荐 WSL](https://github.com/Quantum-Accelerators/quacc/blob/c37a7d7694004422268c9efc8eb89b388192439f/docs/install/install.md)
- [QE core：默认值、static/relax/ASE relax/pp/NSCF](https://github.com/Quantum-Accelerators/quacc/blob/c37a7d7694004422268c9efc8eb89b388192439f/src/quacc/recipes/espresso/core.py)
- [DOS/PDOS recipes](https://github.com/Quantum-Accelerators/quacc/blob/c37a7d7694004422268c9efc8eb89b388192439f/src/quacc/recipes/espresso/dos.py)
- [QE calculator：输入与目录处理](https://github.com/Quantum-Accelerators/quacc/blob/c37a7d7694004422268c9efc8eb89b388192439f/src/quacc/calculators/espresso/espresso.py)
- [设置：二进制映射、并行命令、scratch、results、workflow engine](https://github.com/Quantum-Accelerators/quacc/blob/c37a7d7694004422268c9efc8eb89b388192439f/src/quacc/settings.py)
- [所查版本的 QE recipes 目录](https://github.com/Quantum-Accelerators/quacc/tree/c37a7d7694004422268c9efc8eb89b388192439f/src/quacc/recipes/espresso)

本轮交付仅为接入设计与源码核查；没有安装 quacc、声明 Windows 兼容验证通过或开始新计算。
