# 数据字典与纳入规则 v0.5

适用范围：当前 QE Zn/Cu(111) 项目及其文献证据；不代表已经建立可训练数据集。仅对收到的文件与公开可读取资料作记录，不访问 Windows 本机，不提交、停止、重启或迁移任务。

## 当前研究对象

项目进展文件（SRC002）报告的模型为 24 Cu + 8 Zn，共 32 原子；Cu(111) 六层，双面对称、每面 1 ML Zn。它不是孤立单原子修饰。现已收到真实输入坐标，核实上侧Zn为fcc、下侧为hcp位点，不是两个等价表面；仍未收到原子级实验表征，不能把它认定为真实电沉积结构。

本版本录入摘要、粘贴日志及后续上传的真实.in/.out快照，分别保留证据等级。原件位于../qe_originals，参数映射与四个SCF块的独立复核见../quacc_input_review。不从示意图重建结构，不将拟议量、缺失量或尚未收敛的计算填为有效标签。日志摘录不是完整输出核验；原始文献未核验时保持pending；上传.out可以作为已读快照，但不能把运行未完成误写为最终离子收敛。

## 文件

- `sources.csv`：来源清单；同时区分已读取的软件原文、用户交接摘要和待核验论文线索。
- `observations.csv`：一行一个量或历史里程碑；派生量单独成行，通过引用原记录追溯。
- `audit_report.md`：当前证据等级、算术复核、科学限制和下一步。

两个 CSV 均采用 UTF-8 BOM，便于 Windows Excel 打开。UTF-8 BOM 不改变数值含义。所有 ID 只是本地管理标签，不表示已解析到真实计算/结构，也不是结构去重指纹。

## sources.csv 字段

| 字段 | 定义 |
|---|---|
| source_id | 唯一来源 ID |
| source_type | user_attachment、user_handoff、user_pasted_log_excerpt、official_software_documentation/release、upstream_parser/workflow_source 或 literature_lead_from_attachment |
| title | 原文件/来源题名；待核验论文的题名仅按附件转录 |
| doi / url | 原报告 DOI 或可访问来源地址；有 DOI 不等于已核实论文 |
| local_path | 相对于本目录的已接收本地文件路径；为空表示没有该来源的本地文件 |
| locator | 章节、行所在表格或源码对象，便于人工复核 |
| verification_status | 文件是否读过、资料是否独立核验；不是统一的“科学可信”评分 |
| sha256 | 已接收本地原文件的 SHA-256；只证明当前字节内容，不能证明摘要叙述属实 |
| notes | 访问限制、内容边界与许可/使用限制线索 |

`public_source_checked` 只表明该公开资料被实际读取，不意味着用户的本机设置与它一致。软件资料也不是某个材料体系的性能证据。

## observations.csv 字段

| 字段 | 定义 |
|---|---|
| record_id | 每条观测或派生记录的唯一 ID |
| system_id | 摘要中的模型分组标签；坐标未到前，不作为物理去重依据 |
| run_id | 摘要中的作业/测试标签；`DERIVED_NOT_A_NEW_RUN` 明确不是新计算 |
| source_id / locator | 与来源表关联，并定位原文；多个来源 ID 以分号分隔 |
| property / value / unit | 量名、原始数值和单位；每行单位独立，不能把进展计数与能量混为训练标签 |
| value_relation | reported_scalar/derived_scalar 或 <；estimated scf accuracy 的 < 上界必须保留，不转成等号或真实误差 |
| protocol_id | 下述“报告设置”的标识，不是从输入文件验证过的参数哈希 |
| reference_state | 数值的参照说明；总能不是吸附能，不凭空提供化学势 |
| reference_record_ids | 派生量依赖的原记录 ID，以分号分隔 |
| geometry_status | 固定结构/未核验等；实际结构文件未收到 |
| scf_status | 特定历史 SCF 区块的报告状态；不表示当前作业整体状态 |
| ionic_status | 未核验或不适用；固定结构 SCF 的离子收敛为不适用，而非通过 |
| evidence_status | 区分reported_only、摘要派生、log_excerpt_observed、raw_input_parsed、raw_output_snapshot_parsed、derived_from_raw_output_and_input等；读取真实输出快照不等于最终离子收敛 |
| use_scope | 当前允许的用途：历史进展、报告内真空测试或纯算术复核 |
| ml_eligible | 本版全部为 false；增加字段或收到数值不会自动使之变为 true |
| raw_local_path | 已获取计算证据的云端相对路径；摘要记录为空，日志摘录记录指向保存的摘录文件，不等于完整 .out；不能用 Windows 路径冒充云端已有文件 |
| notes | 与该记录相关的限制、单位缺失或上下文 |

空字段表示未提供/未知，不能自动解释成 0、成功、不适用或计算不存在。`not_applicable` 仅用于逻辑上确实不适用的字段。机器学习是否纳入需另经物理定义、数值质量、任务与分组验证审查。

## 历史报告设置清单：保留原来源状态，最新验证见后文

### P_CU_FIXED_VAC_REPORTED

- Cu 晶格常数 3.63 Å；Cu(111) 2×2、六层，24 Cu。
- ecutwfc=55 Ry，ecutrho=440 Ry，8×8×1 k 点，mv smearing，degauss=0.02 Ry。
- 3 个固定结构 SCF 的真空标签为“每侧 10/15/20 Å”。这里保留原标签；真实周期性 slab 间真空间隙、cell_z 与 slab 厚度须从坐标核对，不能直接按文字标签解读为真空间隙的两倍。
- 没有原始日志，不能独立确认每个 SCF 的收敛，也没有表面能、功函数、截断/k 点或层数收敛结论。

### P_ZNCU_K4_PRERELAX_REPORTED

- Cu(111) 六层，24 Cu + 双面各 4 Zn；每面理想 1 ML。中间两层 Cu 据报告固定。
- 输入名据报告为 cu111_6layer_zn1ml_relax_k4.in；输出同前缀 .out。本机目录据报告为 D:\QE\test\cu_bulk。
- QE 据报告为 7.5；relax/BFGS；4×4×1、CG、local-TF、mixing_beta=0.20、mixing_ndim=4、electron_maxstep=200、conv_thr=1.0d-8、ecutwfc=55 Ry、ecutrho=440 Ry。
- Zn/Cu 输入中实际 smearing、degauss、etot_conv_thr、forc_conv_thr、固定原子 if_pos、晶胞与坐标尚未独立核对；不自动从洁净 Cu 参数复制。
- conv_thr 为电子收敛控制，不能代替离子能量与力阈值。QE 7.5 官方定义中，离子优化同时涉及能量变化及逐分量的力条件，不能只看 total force 或某次 SCF 完成标志。
- 赝势据报告为 Cu_pbe_v1.2.uspp.F.UPF、zn_pbe_v1.uspp.F.UPF、na_pbe_v1.5.uspp.F.UPF；尚未取得文件头、来源和校验和。文件名本身不证明具体赝势内容。文件名大小写不得自行改写。
- 未取得任何最终 Zn/Cu 总能、最终弛豫结构、功函数、Na 吸附结果或 NEB 结果。

## 派生量与物理定义

本版真空测试的派生操作为同一摘要表内的差值：

ΔE(v) = E_reported(v) − E_reported(v=15 Å)。

单位为 Ry/cell；不除以面积、原子数、表面数或 Zn 数，不将其命名为表面能、形成能或吸附能。两条差值可供算术复核，但不构成额外独立样本。

后续收到日志摘录后另增加一个进展描述量：(历史初始总力数值 − 行3308总力数值)/历史初始总力数值 × 100%，约38.3%。此量假设两条记录为同一作业、相同总力口径，只描述两个快照，既不是物理标签，也不证明中间力逐步下降。原始单位标题未到，摘录总力单位保持未提供。

Zn 覆层形成/稳定性与单原子锚定能不是同一个问题。若以后定义覆层相对于洁净 Cu 与 Zn 化学势的能量，必须明确总 Zn 数为 8、两个表面的面积和所用归一化方式，并先验证匹配的 Cu 参照与 Zn 参考相。无论公式最终采用哪种单位，都不得把“每 Zn 原子”“双面每胞”“单面单位面积”混为一列。

Na 吸附能的 Na 参考态、Na 原子数、单面或双面吸附、基底构型与相关计算协议需另外批准。原本双面对称 Zn 覆层不保证加入单面 Na 后仍无净偶极。计算后结构重构也必须记录，不能一直沿用初始位点标签当作最终结构。

## 质量门槛

1. 原始文件可读取，数值与来源定位一致；失败、未完成和未核验状态不得被静默丢弃。
2. 电子 SCF、离子优化、参数收敛和物理模型适用性分别审查；日志关键字是检查线索，不是单独验收器。
3. 派生能量的参考记录、原子计数、单位、参数兼容性完整；不匹配则不进行物理排名。
4. 结构/数值重复须在有真实文件后检查；相同摘要值或同一模型族不直接等于重复/独立样本。
5. 文献 DOI、题名、具体体系、SI 和原始数据来源分别核验；无法核验的记录只作线索。
6. 本版本没有模型训练、主动学习、自动 DFT 提交或计算重启功能。

## P_ZNCU_K4_ACTUAL_INPUT_OUTPUT_CHECKED（v0.3新增）

SRC008为真实输入，SRC009为上传原始UTF-16LE输出，SRC010为严格解码的UTF-8副本。两种输出文件不可作为独立计算样本。

已核验32原子、固定第9–16原子、4×4×1/零偏移、55/440 Ry、mv/0.02 Ry、CG/local-TF/beta0.20/ndim4、初始电子阈值1e-8、能量阈值1e-5 Ry及力阈值5e-4 Ry/bohr。表内RAW_记录以此协议和实际文件为依据，旧报告记录保持不变。

四个已收敛SCF的! total energy为F=E-TS，不与internal energy E或尚未收敛的每轮估计总能混用。新标签smearing_total_energy_F明确该约定。

max_mobile_force_component由完整原子力表中排除输入固定原子的分量后求最大绝对值，仅是分量门槛检查，不替代其他几何优化结束条件。input中的forc_conv_thr用于该比较；Total force不能代替此量。

新记录共28条，包含重复构型的进展指标和输入参数，不增加独立材料数量。总表58条，全部ml_eligible=false。

原始结构的两面不等价，不能自动抵消偶极，也不能把fcc/hcp混合表面的总覆层能按两个等价面解释。后续若创建对称模型，使用新system_id、独立目录和独立输入；不得覆盖当前原始记录。

## 新模型来源（2026-10-28）

SRC011–SRC013记录新建模型的几何检查与输入，状态为generated_model_not_computed；不是性能观测。新Zn/Cu的上下fcc模型与旧fcc/hcp模型分开存储，并有匹配Cu输入。来源表17条；观测表仍58条，全部ml_eligible=false。没有将新结构当作能量标签或将未运行作业标为完成。

## 实际赝势来源（v0.5）

SRC014/015是用户上传的Cu/Zn UPF，文件MD5与SRC009的旧QE输出一致，并保存SHA-256及头信息。该状态不等于赝势上游认证或截断收敛。来源表19条，观测仍58条、ML标签0。
