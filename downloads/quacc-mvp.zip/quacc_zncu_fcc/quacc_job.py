"""Prepare an actual quacc QE input by default. --execute is opt-in."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path

from ase.io import read

HERE = Path(__file__).resolve().parent
EXPECTED_MD5 = {
    "Cu": "6e991ff952a84172a2a52a1c1e996048",
    "Zn": "df62231357ef9e81f77b2b3087fa5675",
}
CASES = ("zncu_fcc_both_k4", "cu111_matching_k4")


def prerequisites(config, pseudo_dir, pw):
    missing = []
    hashes = {}
    if pw is None or not pw.is_file():
        missing.append("QE executable not provided or not a file")
    for element, name in config["pseudopotentials"].items():
        file = pseudo_dir / name if pseudo_dir else None
        if file is None or not file.is_file():
            missing.append(f"Missing pseudopotential: {name}")
        else:
            data = file.read_bytes()
            checksum = hashlib.md5(data).hexdigest()
            hashes[element] = {"md5": checksum, "sha256": hashlib.sha256(data).hexdigest()}
            if checksum != EXPECTED_MD5[element]:
                missing.append(f"Pseudopotential differs from original QE log: {name}")
    return missing, hashes


def run_case(case, output, pseudo_dir=None, pw=None, execute=False, task="scf"):
    if case not in CASES:
        raise ValueError("Unknown reviewed model")
    if task not in ("scf", "relax"):
        raise ValueError("Only the reviewed scf/relax tasks are supported")
    output = output.resolve()
    if not output.is_relative_to(HERE.parent.resolve()):
        raise ValueError("All new files must remain inside the project's Codex directory")
    folder = HERE / "models" / case
    config = json.loads((folder / "config.json").read_text())
    atoms = read(folder / "structure.extxyz")
    missing, hashes = prerequisites(config, pseudo_dir, pw)
    if execute and missing:
        raise ValueError("Execution refused: " + "; ".join(missing))
    output.mkdir(parents=True, exist_ok=False)
    # Set writable paths BEFORE importing quacc; do not use the user's home defaults.
    os.environ["QUACC_RESULTS_DIR"] = str(output / "results")
    os.environ["QUACC_SCRATCH_DIR"] = str(output / "scratch")
    os.environ["MPLCONFIGDIR"] = str(output / "cache/matplotlib")
    os.environ["XDG_CACHE_HOME"] = str(output / "cache")
    from quacc import change_settings, get_settings
    from quacc.calculators.espresso.espresso import Espresso, EspressoTemplate

    binary = pw.resolve() if pw else output / "QE_EXECUTABLE_REQUIRED" / "pw.x"
    pseudo = pseudo_dir.resolve() if pseudo_dir else output / "PSEUDOPOTENTIALS_REQUIRED"
    binaries = dict(get_settings().ESPRESSO_BINARIES)
    binaries["pw"] = binary.name
    settings = {
        "ESPRESSO_BIN_DIR": binary.parent,
        "ESPRESSO_BINARIES": binaries,
        "ESPRESSO_PSEUDO": pseudo,
        "ESPRESSO_PARALLEL_CMD": "",
        "RESULTS_DIR": output / "results",
        "SCRATCH_DIR": output / "scratch",
        "GZIP_FILES": False,
        "WORKFLOW_ENGINE": None,
    }
    # The engine must be None on import; never silently replace a configured engine.
    settings.pop("WORKFLOW_ENGINE")
    if get_settings().WORKFLOW_ENGINE is not None:
        raise ValueError("This minimal entry point requires QUACC_WORKFLOW_ENGINE unset")
    kwargs = copy.deepcopy(config)
    # Runtime paths are isolated. Old D:\QE outdir/.save are never reused.
    kwargs["input_data"]["control"].pop("outdir", None)
    kwargs["input_data"]["control"].pop("pseudo_dir", None)
    kwargs["input_data"]["control"].pop("prefix", None)
    kwargs["input_data"]["control"]["calculation"] = task
    if task == "scf":
        kwargs["input_data"].pop("ions", None)
    with change_settings(settings):
        calc = Espresso(input_atoms=atoms, preset=None, template=EspressoTemplate("pw"), **kwargs)
        input_dir = output / "input_preview"
        input_dir.mkdir()
        calc.directory = input_dir
        calc.write_inputfiles(atoms, ["energy", "forces"])
        from ase.io.espresso import read_fortran_namelist
        with (input_dir / "pw.in").open() as f:
            effective_input, _ = read_fortran_namelist(f)
        manifest = {
            "case": case,
            "task": task,
            "mode": "execute" if execute else "input_preparation_only",
            "QE_executed": False,
            "prerequisites_missing": missing,
            "pseudopotential_hashes": hashes,
            "input_file": str(input_dir / "pw.in"),
            "fixed_atoms_zero_based": [int(i) for c in atoms.constraints for i in c.get_indices()],
            "preset": None,
            "parallel_command": "",
            "effective_prefix": effective_input["control"]["prefix"],
            "effective_outdir": effective_input["control"]["outdir"],
            "note": "No restart files reused. No inferred ionic convergence or ML eligibility.",
        }
        if execute:
            from monty.serialization import dumpfn
            from quacc.recipes.espresso.core import relax_job, static_job

            manifest["QE_execution_attempted"] = True
            (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
            result = (
                static_job(atoms, preset=None, **kwargs) if task == "scf"
                else relax_job(atoms, preset=None, relax_cell=False, **kwargs)
            )
            dumpfn(result, output / "quacc_result.json")
            manifest["QE_executed"] = True
            manifest["human_convergence_review_required"] = True
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", choices=CASES)
    parser.add_argument("--output", type=Path, required=True, help="New directory, never an old QE directory")
    parser.add_argument("--pseudo-dir", type=Path)
    parser.add_argument("--pw", type=Path, help="Absolute path to the platform's QE executable")
    parser.add_argument("--execute", action="store_true", help="Actually run the requested new QE task after prerequisite checks")
    parser.add_argument("--task", choices=("scf", "relax"), default="scf")
    args = parser.parse_args()
    try:
        result = run_case(args.case, args.output, args.pseudo_dir, args.pw, args.execute, args.task)
    except (ValueError, FileExistsError, FileNotFoundError) as exc:
        parser.exit(2, f"error: {exc}\n")
    print(json.dumps(result, indent=2))
