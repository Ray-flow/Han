"""Offline geometry, actual-quacc input, and execution-guard checks."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from ase.io import read
from ase.io.espresso import read_fortran_namelist

from prepare_models import HERE, ORIGINAL, build, registry, symmetry
from quacc_job import run_case, prerequisites


class WorkflowTests(unittest.TestCase):
    def temporary(self):
        folder = tempfile.TemporaryDirectory(dir=HERE.parent)
        self.addCleanup(folder.cleanup)
        return Path(folder.name)

    def test_model_change_is_limited_and_fcc_on_both_sides(self):
        old = read(ORIGINAL, format="espresso-in")
        new = read(HERE / "models/zncu_fcc_both_k4/structure.extxyz")
        self.assertEqual(registry(old)["lower"]["site"], "hcp")
        self.assertEqual(registry(old)["upper"]["site"], "fcc")
        self.assertEqual(registry(new)["lower"]["site"], "fcc")
        self.assertEqual(registry(new)["upper"]["site"], "fcc")
        # extxyz serializes coordinates to 8 decimals; builder checks exact arrays in memory.
        np.testing.assert_allclose(new.positions[:24], old.positions[:24], atol=5e-9, rtol=0)
        np.testing.assert_allclose(new.positions[28:], old.positions[28:], atol=5e-9, rtol=0)
        self.assertEqual(symmetry(old)[1]["surface_exchanging_operations"], 0)
        self.assertGreater(symmetry(new)[1]["surface_exchanging_operations"], 0)

    def test_cu_reference_cell_constraints_and_physical_protocol_match(self):
        zn = read(HERE / "models/zncu_fcc_both_k4/qe.in", format="espresso-in")
        cu = read(HERE / "models/cu111_matching_k4/qe.in", format="espresso-in")
        np.testing.assert_array_equal(zn.cell, cu.cell)
        np.testing.assert_allclose(zn.positions[:24], cu.positions, atol=1e-9)
        self.assertEqual(list(cu.constraints[0].get_indices()), list(range(8, 16)))
        configs = [json.loads((HERE / f"models/{case}/config.json").read_text()) for case in ("zncu_fcc_both_k4", "cu111_matching_k4")]
        for key in ("ecutwfc", "ecutrho", "smearing", "degauss"):
            self.assertEqual(configs[0]["input_data"]["system"][key], configs[1]["input_data"]["system"][key])
        self.assertEqual(configs[0]["kpts"], configs[1]["kpts"])
        self.assertEqual(configs[0]["input_data"]["electrons"], configs[1]["input_data"]["electrons"])

    def test_rebuild_is_deterministic_and_refuses_overwrite(self):
        out = self.temporary() / "models"
        first = build(out)
        second = build(out.parent / "second")
        self.assertEqual(first, second)
        with self.assertRaises(FileExistsError):
            build(out)

    def test_actual_quacc_input_generation_does_not_execute_QE(self):
        from quacc.calculators.espresso.espresso import EspressoTemplate
        out = self.temporary() / "preview"
        with patch.object(EspressoTemplate, "execute", side_effect=AssertionError("QE must not run")):
            manifest = run_case("zncu_fcc_both_k4", out)
        self.assertFalse(manifest["QE_executed"])
        self.assertEqual(len(manifest["prerequisites_missing"]), 3)
        atoms = read(out / "input_preview/pw.in", format="espresso-in")
        self.assertEqual(list(atoms.constraints[0].get_indices()), list(range(8, 16)))
        self.assertEqual(registry(atoms)["lower"]["site"], "fcc")
        with (out / "input_preview/pw.in").open() as f:
            data, _ = read_fortran_namelist(f)
        self.assertEqual(data["electrons"]["mixing_beta"], 0.20)
        self.assertEqual(data["system"]["degauss"], 0.02)
        self.assertEqual(data["control"]["calculation"], "scf")
        self.assertFalse(data.get("ions"))  # ASE may emit an empty namelist.
        self.assertNotIn("D:", data["control"]["outdir"])
        self.assertTrue(Path(data["control"]["outdir"]).is_relative_to(out))
        relaxed_preview = self.temporary() / "relax_preview"
        with patch.object(EspressoTemplate, "execute", side_effect=AssertionError("QE must not run")):
            run_case("zncu_fcc_both_k4", relaxed_preview, task="relax")
        with (relaxed_preview / "input_preview/pw.in").open() as f:
            relaxed, _ = read_fortran_namelist(f)
        self.assertEqual(relaxed["control"]["calculation"], "relax")
        self.assertEqual(relaxed["ions"]["ion_dynamics"], "bfgs")

    def test_execution_refused_before_writing_if_dependencies_missing(self):
        out = self.temporary() / "not_created"
        with self.assertRaisesRegex(ValueError, "Execution refused"):
            run_case("zncu_fcc_both_k4", out, execute=True)
        self.assertFalse(out.exists())

    def test_changed_pseudopotential_is_rejected(self):
        folder = self.temporary()
        (folder / "Cu_pbe_v1.2.uspp.F.UPF").write_text("not the reviewed pseudopotential")
        config = {"pseudopotentials": {"Cu": "Cu_pbe_v1.2.uspp.F.UPF"}}
        missing, _ = prerequisites(config, folder, ORIGINAL)
        self.assertTrue(any("differs" in item for item in missing))

    def test_preview_does_not_change_original_files(self):
        before = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
        out = self.temporary() / "preview"
        run_case("cu111_matching_k4", out)
        self.assertEqual(hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(), before)
        with self.assertRaises(FileExistsError):
            run_case("cu111_matching_k4", out)

    def test_recipe_merges_to_reviewed_physical_values(self):
        from quacc.recipes.espresso.core import relax_job
        from quacc.recipes.espresso._base import prepare_calc
        from quacc.calculators.espresso.espresso import EspressoTemplate
        config = json.loads((HERE / "models/zncu_fcc_both_k4/config.json").read_text())
        atoms = read(HERE / "models/zncu_fcc_both_k4/structure.extxyz")
        # Exercise the actual recipe's parameter merge without Runner or a binary.
        def intercepted(*args, **kwargs):
            calc = prepare_calc(atoms=args[0], preset=kwargs["preset"], template=EspressoTemplate("pw"), calc_defaults=copy.deepcopy(kwargs["calc_defaults"]), calc_swaps=copy.deepcopy(kwargs["calc_swaps"]))
            return calc.parameters
        with patch("quacc.recipes.espresso.core.run_and_summarize", side_effect=intercepted):
            merged = relax_job(atoms, preset=None, relax_cell=False, **copy.deepcopy(config))
        for section in ("system", "electrons", "ions"):
            for key, value in config["input_data"][section].items():
                self.assertEqual(merged["input_data"][section][key], value)
        self.assertEqual(merged["input_data"]["control"]["forc_conv_thr"], 0.0005)


if __name__ == "__main__":
    unittest.main()
