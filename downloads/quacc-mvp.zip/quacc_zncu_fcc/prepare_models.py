"""Build a separate, inversion-symmetric fcc/fcc model; never run QE."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path

import numpy as np
from ase.geometry import find_mic
from ase.io import read, write
from ase.io.espresso import read_fortran_namelist, write_espresso_in
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.optimize import linear_sum_assignment

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / "qe_originals/cu111_6layer_zn1ml_relax_k4.in"
MAPPING = HERE.parent / "quacc_input_review/quacc_parameter_mapping_REVIEW_ONLY.json"


def symmetry(atoms):
    analyzer = SpacegroupAnalyzer(AseAtomsAdaptor.get_structure(atoms), symprec=1e-3)
    return analyzer, {
        "space_group": analyzer.get_space_group_symbol(),
        "number": int(analyzer.get_space_group_number()),
        "surface_exchanging_operations": sum(
            np.allclose(op.rotation_matrix[2], [0, 0, -1])
            for op in analyzer.get_symmetry_operations()
        ),
    }


def registry(atoms):
    """Identify hollow registry by alignment with second/third inward Cu layers."""
    cu = [i for i, a in enumerate(atoms) if a.symbol == "Cu"]
    zn = [i for i, a in enumerate(atoms) if a.symbol == "Zn"]
    levels = sorted(set(np.round(atoms.positions[cu, 2], 8)))
    middle = (levels[0] + levels[-1]) / 2
    result = {}
    for side, inward in [("lower", levels), ("upper", levels[::-1])]:
        distances = []
        for i in zn:
            if (atoms.positions[i, 2] < middle) != (side == "lower"):
                continue
            matches = []
            for level in inward[1:3]:
                indices = [j for j in cu if abs(atoms.positions[j, 2] - level) < 1e-6]
                delta = atoms.positions[indices] - atoms.positions[i]
                delta[:, 2] = 0
                _, d = find_mic(delta, atoms.cell, pbc=[True, True, False])
                matches.append(float(min(d)))
            distances.append(matches)
        if not distances:
            result[side] = {"site": "no_Zn"}
            continue
        d = np.array(distances)
        site = "fcc" if np.all(d[:, 1] < 1e-5) else "hcp" if np.all(d[:, 0] < 1e-5) else "other"
        result[side] = {"site": site, "second_third_layer_distances_A": distances}
    return result


def repaired_atoms(original):
    if original.get_chemical_formula() != "Cu24Zn8":
        raise ValueError("This preparation is specific to the reviewed Cu24Zn8 input")
    bare = original[:24]
    analyzer, _ = symmetry(bare)
    inversion = next(
        op for op in analyzer.get_symmetry_operations()
        if np.allclose(op.rotation_matrix, -np.eye(3))
    )
    top_fractional = original.get_scaled_positions(wrap=False)[28:32]
    targets = np.mod(inversion.operate_multi(top_fractional), 1) @ original.cell.array
    delta = targets[None, :, :] - original.positions[24:28, None, :]
    _, distances = find_mic(delta.reshape(-1, 3), original.cell, pbc=True)
    rows, cols = linear_sum_assignment(distances.reshape(4, 4))
    result = original.copy()
    result.positions[24 + rows] = targets[cols]
    assert np.array_equal(result.positions[:24], original.positions[:24])
    assert np.array_equal(result.positions[28:], original.positions[28:])
    assert registry(result)["lower"]["site"] == registry(result)["upper"]["site"] == "fcc"
    assert symmetry(result)[1]["surface_exchanging_operations"] > 0
    return result


def build(destination, original_path=ORIGINAL, mapping_path=MAPPING):
    destination = destination.resolve()
    if not destination.is_relative_to(HERE.parent.resolve()):
        raise ValueError("All new files must remain inside the project's Codex directory")
    metadata = json.loads(mapping_path.read_text(encoding="utf-8"))
    digest = hashlib.sha256(original_path.read_bytes()).hexdigest()
    if digest != metadata["original_sha256"][original_path.name]:
        raise ValueError("Original input hash differs from the reviewed input")
    original = read(original_path, format="espresso-in")
    fixed = [int(i) for c in original.constraints for i in c.get_indices()]
    if fixed != list(range(8, 16)):
        raise ValueError("Unexpected frozen atoms")
    repaired = repaired_atoms(original)
    destination.mkdir(parents=True, exist_ok=False)
    systems = {"zncu_fcc_both_k4": repaired, "cu111_matching_k4": original[:24]}
    report = {
        "original_sha256": digest,
        "basis": "original initial input, not a converged or stable structure",
        "original_registry": registry(original),
        "original_symmetry": symmetry(original)[1],
        "changed_atoms_one_based": [25, 26, 27, 28],
        "new_coordinates_lower_Zn_A": repaired.positions[24:28].tolist(),
        "repaired_registry": registry(repaired),
        "models": {},
        "QE_executed": False,
    }
    for name, atoms in systems.items():
        folder = destination / name
        folder.mkdir()
        data = copy.deepcopy(metadata["physical_input_data"])
        data["system"].update(nat=len(atoms), ntyp=len(set(atoms.symbols)))
        data["control"].update(prefix=name + "_v1", outdir="./scratch", pseudo_dir="./pseudo")
        pp = {s: metadata["pseudopotentials"][s] for s in set(atoms.symbols)}
        write(folder / "structure.extxyz", atoms, format="extxyz")
        with (folder / "qe.in").open("w", encoding="utf-8", newline="\n") as f:
            write_espresso_in(f, atoms, input_data=data, pseudopotentials=pp, kpts=(4, 4, 1), koffset=(0, 0, 0))
        config = {"input_data": data, "pseudopotentials": pp, "kpts": [4, 4, 1], "koffset": [0, 0, 0]}
        (folder / "config.json").write_text(json.dumps(config, indent=2) + "\n")
        # Verify what QE will actually receive, including regenerated if_pos.
        again = read(folder / "qe.in", format="espresso-in")
        with (folder / "qe.in").open() as f:
            parsed, _ = read_fortran_namelist(f)
        assert parsed["system"]["nat"] == len(atoms)
        assert np.max(abs(again.positions - atoms.positions)) < 1e-8
        assert list(again.constraints[0].get_indices()) == fixed
        d = atoms.get_all_distances(mic=True)
        np.fill_diagonal(d, np.inf)
        report["models"][name] = {
            "formula": atoms.get_chemical_formula(),
            "symmetry": symmetry(atoms)[1],
            "minimum_pair_distance_A": float(d.min()),
            "fully_fixed_indices_zero_based": fixed,
            "geometry_roundtrip_passed": True,
        }
    (destination / "model_checks.json").write_text(json.dumps(report, indent=2, default=int) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "models")
    args = parser.parse_args()
    report = build(args.output)
    print(json.dumps(report["models"], indent=2))
