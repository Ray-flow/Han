# Zn/Cu(111) 双面 fcc 基准与 quacc 最小入口

更新：2026-10-28。**模型和离线流程已修正、已测试；未运行新 DFT，也没有修改旧任务。**

## 修正了什么

原始输入是上侧fcc、下侧hcp，不是两个等价表面。本版保留原始32原子模型作为对照，另以原始初始结构为起点，只重新放置第25–28号下侧Zn，使其成为上侧Zn经Cu基底反演操作得到的对应位点。Cu及上侧Zn在构建时完全不变；extxyz序列化有约10⁻⁹ Å量级的舍入。

新模型：上下均为fcc，P-3m1（164），有交换上下表面的对称操作。仍保留原有8个固定Cu与原有计算精度设置。这只是几何初始模型，不证明能量最低、无重构或实际电沉积结构。几何反演对称支持取消由结构不对称产生净偶极的担忧，但并不是已计算的电势/偶极验收；后续弛豫后应复查。

同时建立24 Cu的匹配参照，保留相同晶胞、Cu初始坐标、固定层、cutoff、k网格及展宽。由于移除Zn，最外层原子之间的几何真空间隙会改变；“匹配”指计算晶胞与协议，不宣称两种表面的最外原子间距相同。参照尚未弛豫或计算。

## 文件

- `models/zncu_fcc_both_k4/`：新Cu24Zn8结构、QE原生relax输入草案、参数配置。
- `models/cu111_matching_k4/`：匹配Cu24参照，同类文件。
- `models/model_checks.json`：来源哈希、改变的原子、位点、对称性、最小原子间距和约束检查。
- `prepare_models.py`：可复现模型生成；输出目录必须不存在，禁止覆盖。
- `quacc_job.py`：调用安装的quacc生成真实QE输入；默认任务为静态SCF且只准备输入。
- `test_workflow.py` / `test_results.txt`：8项离线回归检查及本次结果。
- `requirements.txt`：本轮实际环境的固定版本依赖清单，quacc固定到核查过的Git提交。
- `previews/`：本轮通过实际quacc生成的SCF/relax输入样例，标有缺失前提。它们含云端路径，不应直接拿去本机启动，必须重新生成。

原始.in/.out在同级`../qe_originals/`，仍保留原始字节。其他审查依据位于`../quacc_input_review/`。不要把新模型的坐标、总能或目录回填到旧的fcc/hcp作业。

## 已验证与未验证

已验证：两面位点、反演对称性、固定索引、匹配Cu参照、确定性重建、实际quacc输入生成及其物理参数、原生recipe参数合并、缺失或不匹配赝势时拒绝执行、默认不调用QE、旧文件不变。

没有验证：真实QE执行、赝势的截断收敛与数值表现、Windows pw.exe与quacc兼容性、Windows/Linux重启文件兼容性、电子/离子收敛、k点/截断/真空收敛和任何新能量。测试中recipe合并使用拦截Runner之前的方式检查，不把它算成完成了DFT。

quacc内会将prefix管理为`pwscf`；不同任务靠独立目录和结果记录区分，不能手动令它们共享outdir。默认不复用任何旧.save。读取QE输出并不会自动恢复ASE固定约束，本入口从带约束的结构文件载入并检查它们。

quacc==1.8.3在本次包索引查询中不可直接取得，因此环境安装固定到GitHub源码提交`c37a7d7694004422268c9efc8eb89b388192439f`，没有改用其他未核查版本。requirements清单固定了版本及Git提交，不等同于所有依赖的完整制品哈希锁；正式换机器仍需复验。

## 当前云端可用的命令（均不运行QE）

在此目录下：

```bash
/workspace/Codex/quacc_review_env/bin/python -B quacc_job.py zncu_fcc_both_k4 --output ../runs/preview_01
/workspace/Codex/quacc_review_env/bin/python -B quacc_job.py zncu_fcc_both_k4 --task relax --output ../runs/preview_relax_01
```

输出目录必须是新的、位于Codex内。默认缺失程序/赝势时仍可准备输入，但manifest会明确列出缺口，不能称为可执行环境已就绪。

重新构建模型到新目录：

```bash
/workspace/Codex/quacc_review_env/bin/python -B prepare_models.py --output models_rebuild
```

## 真正执行以前

Cu/Zn UPF文件现已收到，完整MD5与旧QE日志一致，SHA-256及头信息见../pseudo/verification.json。实际路径的输入预览见previews_verified_pseudo。仍需选定运行平台和QE程序。入口继续核对实际文件MD5并保存SHA-256；这用于保证与原作业一致，不代替赝势来源和质量检查。换赝势必须另立协议，不能简单移除不匹配检查。

需要显式提供`--pw`、`--pseudo-dir`、新的`--output`，并添加`--execute`才会运行QE。`--task scf`为默认；`--task relax`才进行原生BFGS。入口没有启动MPI命令，不承诺改变性能；线程/并行设置需在实际平台核验，不应直接复制旧Windows的12线程设置。

先做同一几何、同一协议的直接QE与quacc静态SCF对照；这不是拿新fcc/fcc模型与旧fcc/hcp能量做“等价性”比较。数值容差需结合实际构建与精度确定。对照通过后才逐步执行新弛豫；正常返回还需要人工审查输出、力/能量阈值与最终结构，不自动进入ML。

Windows官方建议WSL，但目前没有安装或迁移WSL。任何本机环境、缓存、临时文件和结果必须先规划到D:\Codex；未获得许可不采用会写C盘的默认安装流程。当前所有新增环境、缓存与文件位于获准的云端/workspace/Codex。

## 仍不在本版范围

Zn体相化学势、Na参考态、覆层能/吸附能公式、最终k点、NEB、功函数、Bader、ML与服务器购买均未自动决定或执行。本版不添加这些尚未确认的科学条件。

## 来源与许可

计算工作流复用[quacc](https://github.com/Quantum-Accelerators/quacc/tree/c37a7d7694004422268c9efc8eb89b388192439f)（BSD-3）、ASE与pymatgen，项目脚本仅包含模型变换、薄参数入口与检查。没有复制或修改上游源文件。旧输入来自用户，哈希见model_checks.json；数据证据等级仍按MVP数据字典区分。

## 赝势更新（2026-10-28）

实际Cu/Zn文件已保存于../pseudo，MD5匹配、PBE/US/元素/价电子信息核对通过，Cu24Zn8总价电子数616与旧日志一致。新预览不再缺赝势，只缺实际QE程序；未执行DFT。文中的早期previews目录保留当时缺文件的检查结果，新状态以previews_verified_pseudo和../pseudo/verification.json为准。
