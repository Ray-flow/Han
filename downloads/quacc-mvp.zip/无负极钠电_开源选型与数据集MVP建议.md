# 无负极钠电：开源选型与数据集 MVP 建议

核查日期：2026-10-27，Asia/Shanghai。

本报告依据用户上传的《无负极钠电_Codex_GPT_最快科研执行计划.md》及公开源码、README、依赖声明、许可证和默认分支提交记录。附件中的操作指令仅作为待审查计划，不构成执行授权。本轮未开发代码、安装新项目或运行 DFT。

## 1. 结论与目标修正

**推荐“基于成熟开源组件做最小适配”，首期不开发通用平台，不训练模型。**

用户确认的第一阶段是建立数据集与分析流程。附件的 A 线是单原子修饰 Cu 集流体的 DFT 数据生成与材料筛选；B 线是死钠再活化介体。两线的数据对象、参考态、软件与验证标准不同，不能合并成一张训练表。

主线最小技术组合：pymatgen-core + 常规表格处理与绘图。已有科学环境包含 pymatgen/pymatgen-core；本轮没有升级或变更它们。ASE 作为后续表面结构生成的成熟工具按需加入；若确实需要自动运行新计算，再选 quacc。无需为了首批数据引入 AiiDA、MongoDB、任务守护进程、Web 前端或完整 ML 框架。

如果实验室已经使用 atomate2 或 AiiDA，优先沿用现有基础设施，不另搭一套。用户回复资源问题为“尚未确定”；这并不证明已经拥有或完全没有 DFT/文献数据。因此当前建议不依赖任何软件许可、已有输出或 HPC 已经可用。

**落实到当前首期：先建立文献证据表、数据字典和质量审查规则，不将产生新 DFT 数据或编写解析器列为立即交付。** 资源与真实输出样例明确后，再进入自动导入阶段。

## 2. GitHub 项目比较

以下日期是默认分支最新可见提交日期，统一按北京时间换算。它是活动证据，不代表维护承诺、发布版本或测试全部通过。部署难度是根据文档与依赖作出的工程判断，未进行安装验证；实际采用时应固定已验证的发布版本，而不是盲目安装 main。

| 项目 | 活动/许可 | 可复用功能 | 部署与本项目判断 |
|---|---|---|---|
| [pymatgen-core](https://github.com/materialsproject/pymatgen-core) / [pymatgen](https://github.com/materialsproject/pymatgen) | core 2026-10-27；MIT | 原子结构、结构读写、VASP 输入输出与能量/收敛信息；上层 pymatgen 提供更多分析 | 低到中；已有环境可用。首期优先调用现成解析器，只写项目字段映射与质量检查。安装解析器不等于拥有 VASP、赝势或计算资源 |
| [quacc](https://github.com/Quantum-Accelerators/quacc) | 2026-10-27；BSD-3；查见版本 1.8.3 | VASP slab relax/static、bulk-to-slabs、slab-to-adsorption；另有 QE 和 ORCA recipes | 本地小工作流中等；配置 HPC 后成本增加。Python >=3.11，依赖 ASE 和 pymatgen-core；实际电子结构程序需另配。最适合后续计算自动化，首期数据整理无需部署 |
| [atomate2](https://github.com/materialsproject/atomate2) | 2026-10-27；modified BSD | 标准化材料工作流、jobflow、custodian、计算记录和输出文档 | 中到高；当前主分支要求 Python 3.12+。可本地运行，外部数据库不是所有场景的硬要求；分布式调度与存储增加配置。实验室已有则复用，否则首期不引入 |
| [AiiDA](https://github.com/aiidateam/aiida-core) | 2026-10-22；MIT | 输入—计算—输出溯源图、远程作业、恢复与插件 | 入门可用 SQLite；当前 quick-start 也有内建 ZeroMQ，因此不能说必须先装 PostgreSQL/RabbitMQ。生产高通量部署仍增加运维。适合长期平台，不是本 MVP 最短路径 |
| [matminer](https://github.com/hackingmaterials/matminer) | 2026-10-27；BSD 类许可 | 元素/组成/结构描述符 | 第二阶段可直接使用；不产生真实 DFT 标签，首期不必安装 |
| [RDKit](https://github.com/rdkit/rdkit) + [cclib](https://github.com/cclib/cclib) | RDKit 2026-10-26，BSD；cclib main 2026-07-31，BSD-3 | 介体 SMILES/描述符/构象；量化输出解析 | B 线需要时再用。解析器对具体 ORCA 版本、任务和自由能字段的覆盖需样例验证。RDKit 不会自动得到可信氧化还原电位 |
| [BayBE](https://github.com/emdgroup/baybe) | 2026-10-26；Apache-2.0 | 参数空间、代理模型、批量候选推荐、结果回填 | 未来主动学习可复用；目前没有可信标签时无须部署，其建议也不等于实验验证 |

ASE 的权威上游实际位于 [GitLab](https://gitlab.com/ase/ase)，不能把不明 GitHub 镜像当官方项目。本轮核实其主分支仍有 2026-10-27（北京时间）提交；当前 pyproject 要求 Python >=3.11，LICENSE 声明 LGPL-2.1-or-later。它已有表面构建、计算器接口和数据库工具。先查 GitHub 的原则不应导致排除其他平台上的成熟权威上游。

### 上一轮项目为什么不再作为主框架

- [BatteryML](https://github.com/microsoft/BatteryML)：主要是循环退化与寿命预测，不是 Cu 表面 DFT 数据流水线。默认分支最新提交为 2024-12-18；requirements 要求 NumPy <2，不宜直接与现有环境混装。
- [BEEP](https://github.com/TRI-AMDD/beep)：循环仪器数据处理有价值，适合后续 Na||Cu/全电池实验文件；不负责表面结构与 DFT 参考能。
- [AL-anode-free](https://github.com/ritesh001/AL-anode-free)：无负极锂电解液主动学习的论文代码，MIT，方法可参考；不是钠单原子集流体数据集或可直接迁移的钠电模型。
- [钠基电解液主动学习](https://github.com/TibMont/active-machine-learning-for-sodium-based-batteries)：与钠相关但目标主要是离子电导率，不能替代 Na 吸附、单原子稳定性、CE 或全电池寿命数据。依赖 LECA/PyALAF，根目录未发现许可证，代码与数据使用权需另核实。

使用单原子、钠、Cu、吸附、机器学习等组合词检索后，本轮没有找到经验证可直接覆盖本课题的成熟端到端仓库。这是有限检索结论，不等于证明相关项目不存在。

## 3. 附件前提审查

### 3.1 负的锚定能不是“单原子稳定存在”的充分证据

相对于孤立原子的结合有利，不代表相对于金属团簇、体相金属、表面合金或其他位点稳定。吸附型、替位型、空位锚定型模型涉及的原子数和参考态不同。应明确金属与 Cu 的化学势、覆盖度、位点、弛豫后的真实构型；仅有一个负能量值不能证明实验中的单原子稳定性。

### 3.2 Na 吸附能不能直接作为成核、死钠或寿命标签

单个 Na 的吸附反映特定理想模型与参考态下的结合，不等于成核势垒，也不能单独证明迁移快、沉积均匀、SEI 稳定或死钠减少。真空理想表面与实际电解液、氧化层、缺陷、SEI、工作电位下的界面不同。相关结果首先应表述为计算描述符，不写成已证实的电池性能。

### 3.3 参考态必须可追溯

以孤立 Na 原子或体相 Na 为参考会改变吸附能数值和解释。不同泛函、赝势、超胞、覆盖度的文献值也不能未经处理直接合并训练。原始文献定义和统一定义应分别保留，无法换算的记录不强行换算。

每个派生能量必须关联其所用基底、吸附体系与参考能记录，且计算协议兼容。替位模型必须核对移入/移出的原子与参考化学势。本轮不替用户批准任何最终公式。

### 3.4 “20–40 / 30–50 条数据后上 ML”不是通用门槛

同一元素的多个近似结构不等于独立化学样本。是否可建模取决于元素与位点覆盖、标签噪声、任务难度和验证方案。按元素分组有助于评估外推，但不能单凭 GroupKFold 就声称可以可靠预测任意新元素。小数据 SHAP 可作探索，不能直接解释因果机制。

若筛选时尚无目标候选的弛豫结构、功函数或 Bader 电荷，就不能把这些计算后才知道的量作为“零计算预测”特征而不计入成本。

### 3.5 功函数与收敛状态必须单独审查

功函数需要可靠真空电势参考和费米能，涉及 slab/vacuum 收敛及可能的偶极修正；不能仅从一个总能输出字段推算。程序正常结束不等于电子与离子收敛，也不等于物理模型合理。静态任务与弛豫任务的收敛验收应区分。

### 3.6 介体“回收死钠”尚缺完整反应闭环

例如中性电子受体 M 接受 Na 的电子时，可写成 Na⁰ + M → Na⁺ + M⁻，但还必须解释 M⁻ 如何再生、电子流向哪里、是否形成可利用容量，以及是否发生不可控氧化还原穿梭。

把 Na 转成 Na⁺不自动等于恢复可用库存或容量。介体还可能攻击新鲜 Na，造成自放电；必须有空间选择性、界面保护或受控再生机制。还需区分失联金属 Na、SEI 中的钠和其他不可逆损失，不能统称为可被同一种介体回收的“死钠”。

“Nafion 是语音识别错误”只能算附件作者的猜测。应向老师核对名称，不能预先认定它一定是氧化还原介体。A 线数据整理不必因此停工，但 B 线机理和分子计算应等待身份确认。

### 3.7 时间表和论文创新性不能预先承诺

附件的 7/14/30 天目标没有核实软件许可、HPC 配额、排队、结构收敛、实验制备与表征条件。可以作为愿望清单，不可用作已验证工期，也不宜据此判断“进度太慢”。表面结合、反应热力学有利或容量回升中的任一项，都不足以单独证明完整的再活化机制或高水平论文可行性。

## 4. 附件文献的独立核查状态

本轮尝试通过 Crossref 与 DOI 内容协商读取元数据，均遇网络代理 403，未取得可独立核对的题名、作者和出版信息。以下四条仅按附件转录为待核验记录，不据此判断论文不存在，也不把其存在、性能数字或机理结论当作已核实事实：

| 附件声称的工作 | DOI | 本轮状态 |
|---|---|---|
| Reactivating dead sodium for durable and high-rate anode-free sodium batteries | 10.1038/s41467-026-72848-0 | 待核验 |
| Interface Reconstruction Reviving Dead Na Enables 3,800-Cycle Ah-Level Anode-Free Sodium Batteries | 10.1002/adma.74820 | 待核验；题名中的数值不作为本报告结论 |
| Data-Driven Knowledge Discovery Reveals Quantitative Electrolyte Design Rules for Anode-Free Sodium Metal Batteries | 10.1021/jacs.6c05130 | 待核验；目前无法确认是否有相应公开代码/数据 |
| Active sodium loss in practical anode-free sodium batteries: mechanisms, challenges, and strategies | 10.1039/D6EE00760K | 待核验 |

后续须取得出版商元数据及论文/SI，核对 DOI、体系、测试条件、原始数据与机制证据后，才能用于创新性冲突矩阵。本轮不承诺“首次”“空白”或“高创新”。

## 5. 最简单的 MVP：先得到能审计的数据，而不是预测器

### 范围

只做 A 线 Cu 集流体，先整理已有的结构、DFT 输出和人工核验文献记录。若暂时没有自有输出，先完成带来源的文献与数据可得性清单，并标注缺口；不合成 DFT 数值，不启动大规模新计算。

B 线暂时只保留独立的分子/证据清单和“名称待确认”状态，不与 A 线共用标签表，不运行 xTB/ORCA。

### 最小交付物

1. `sources.csv`：source_id、来源类型、DOI/URL、原始文件路径、页码/图表/SI 位置、核验状态、数据使用条件。
2. `observations.csv`：record_id、system_id、source_id、Cu 晶面、修饰元素、位点/模型类型、原始和最终结构路径、性质名称、原始数值/单位、参考态、protocol_id、收敛/质量状态、原始输出路径、派生量依赖的记录 ID。
3. `definitions.md`：字段、单位、公式与参考态、协议标识规则、允许比较的条件、去重规则、失败/缺失原因；物理定义待用户确认后执行。
4. 受保护的原始文件及一份可重现的数据审计报告；报告列出缺失、重复、未收敛、协议冲突和各候选的数据覆盖情况。

这是一份待批准的交付设计，本轮没有创建以上项目文件或空数据表。CSV 是小规模人工审阅与交换格式；后续如需频繁查询或更大规模结构存储，再迁移 SQLite/ASE DB，不并行维护多套主数据库。

### 分析边界

- 第一批输出是覆盖/缺失/质量统计；只有参考态与协议兼容时才画吸附能、稳定性等比较图。
- 文献值与自算值保留来源区分，不将不同泛函的总能直接比较。
- 状态区分通过、失败、未完成、未核验和不适用；缺失不填 0，未收敛不伪装为正常样本。
- 自动解析复用 pymatgen-core 等成熟解析器，只补项目字段映射、单位/参考记录检查和审计逻辑。程序读出数值不代表验证了其物理正确性。
- 若后续用户要新建 Cu(111)/Au、Sn、Zn、Ag、Bi 修饰体系，先批准模型和基准。基底、参考相、吸附前后体系是多项关联计算，不能把候选元素数量当成作业数或可靠样本数。

### 验收标准

- 每个纳入比较的数值都能追到明确的论文位置或原始计算文件。
- 数据定义、单位、参考态和计算协议可检查；不兼容记录保留但不混排。
- 重复数据与结构来源可辨识；人工复核的一组记录与解析结果一致。
- 同一输入可重现同一质量报告；失败与缺失不会被静默丢弃。
- 原始文件不覆盖，数据清洗与派生记录留痕。

不把高 R²、候选 Top 3、SHAP 图或论文级结果列为首期验收条件。

## 6. 后续采用顺序与成本

先批准数据字典与样例记录；首期以可核查的文献/SI 和数据可得性清单为入口。若原文或数值尚不可得，保留“待核验/未公开/需作者提供”等状态，而不是填出数值。实际数据和计算资源明确后，才实现最小自动导入/审计流程。需要新 DFT 时，优先复用 quacc 的表面/吸附流程，选择 VASP 或 QE 后只对接一种计算引擎；已有 atomate2/AiiDA 则沿用。

DFT 的主要成本来自计算程序与赝势可得性、许可、HPC 排队、多个几何/磁态、参考体系和收敛验证，而不是 Python 包安装。VASP 不是开源免费计算引擎；安装开源自动化工具不授予 VASP 使用许可。QE 为开源选择，但并非不需要伪势、收敛测试和计算资源，也不应只因免费就替换实验室成熟协议。

有足够覆盖与可信标签后再比较简单基线和 GPR/RF；需要新候选的真实计算/实验反馈时再接主动学习。没有可执行反馈环路时，先做静态模型评价，不把候选打分称为已完成主动学习。

## 7. 可核查的一手证据

- pymatgen-core 活动：[2026-10-27 commit](https://github.com/materialsproject/pymatgen-core/commit/6ea05468fd7721c71d35f6de78cb0f2711758e4c)；[VASP 输出解析源码](https://github.com/materialsproject/pymatgen-core/blob/main/src/pymatgen/io/vasp/outputs.py)。
- quacc 活动：[最新核查 commit](https://github.com/Quantum-Accelerators/quacc/commit/c37a7d7694004422268c9efc8eb89b388192439f)；[依赖声明](https://github.com/Quantum-Accelerators/quacc/blob/main/pyproject.toml)；[VASP slab/adsorption 源码](https://github.com/Quantum-Accelerators/quacc/blob/main/src/quacc/recipes/vasp/slabs.py)；[QE 核心 recipes](https://github.com/Quantum-Accelerators/quacc/blob/main/src/quacc/recipes/espresso/core.py)。
- atomate2 活动：[最新核查 commit](https://github.com/materialsproject/atomate2/commit/d31092a2dfcf109f778786a47bf6a8d7e82e8899)；[README 与本地运行说明](https://github.com/materialsproject/atomate2#readme)。
- AiiDA 活动：[最新核查 commit](https://github.com/aiidateam/aiida-core/commit/27b803cbea8e058987f1ee593b7faf1eccc6eec4)；[SQLite/消息代理 quick-start 原文](https://github.com/aiidateam/aiida-core/blob/main/docs/source/installation/guide_quick.rst)。
- ASE：[权威源码](https://gitlab.com/ase/ase)；[许可证](https://gitlab.com/ase/ase/-/blob/master/LICENSE)；[依赖与 Python 要求](https://gitlab.com/ase/ase/-/blob/master/pyproject.toml)；[数据库接口](https://gitlab.com/ase/ase/-/blob/master/ase/db/core.py)。
- matminer 活动：[最新核查 commit](https://github.com/hackingmaterials/matminer/commit/02c60582dc31575298db91b9e978f9cab2966b44)。
- RDKit 活动：[最新核查 commit](https://github.com/rdkit/rdkit/commit/fbb0f798a5d5dec4a7ddda7565cbbe4cbf23ace6)；cclib 活动：[main 核查 commit](https://github.com/cclib/cclib/commit/34ead5f2eeedc3da6c680d1758bfdc285a5ed591)。
- BayBE：[README](https://github.com/emdgroup/baybe#readme)；[最新核查 commit](https://github.com/emdgroup/baybe/commit/9161cbbb74e4205ad0dcbcc561e32f7a0c0b4a84)。
- BatteryML：[依赖声明](https://github.com/microsoft/BatteryML/blob/main/requirements.txt)；[2024-12-18 commit](https://github.com/microsoft/BatteryML/commit/2861ae3b8c79938c7fc8e6fe9986b799ca71c7dd)。
- 钠电解液项目：[研究目标与数据说明](https://github.com/TibMont/active-machine-learning-for-sodium-based-batteries#readme)。

## 8. 待用户确认

是否批准上述“A 线文献证据与数据质量审查”MVP？用户已回复计算软件和资源尚未确定；首期无需先解决这些条件。已有数据情况不作推断，在后续有真实样例时再核对。

批准前不开发、不批算。获准后先查看少量真实样例以确定数据入口，再实现必要逻辑。今后本项目产生的文件均放在 /workspace/Codex 云端临时目录；当前环境无法直接写入 D:\Codex，最终需由用户下载到该目录。附件中的建仓库、脚本与计算任务未执行。
